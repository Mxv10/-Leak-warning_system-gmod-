if SERVER then util.AddNetworkString("WarningSystem7452em:7452") end

WarningSystem7452em.NetsList = WarningSystem7452em.NetsList or {}

function WarningSystem7452em:NetReceive(strName, fnCallback)
	WarningSystem7452em.NetsList[strName] = fnCallback
end

function WarningSystem7452em:NetStart(strName, tblToSend, pTo)
	local tbl, iLen = WarningSystem7452em:Compress(tblToSend)

	net.Start("WarningSystem7452em:7452")
		net.WriteString(strName)
		net.WriteUInt(iLen, 32)
		net.WriteData(tbl, iLen)
	if SERVER then
		if pTo and IsValid(pTo) then
			net.Send(pTo)
		else
			net.Broadcast()
		end
	else
		net.SendToServer()
	end
end

net.Receive("WarningSystem7452em:7452", function(_, pSender)
	local strName = net.ReadString()

	-- net delay
	if SERVER then
		pSender.WarningSystem7452emNets = pSender.WarningSystem7452emNets or {}
		if (pSender.WarningSystem7452emNets[strName] or 0) > CurTime() then return end
		pSender.WarningSystem7452emNets[strName] = CurTime() + 0.1
	end

	local iLen = net.ReadUInt(32)
	local tCompressed = net.ReadData(iLen)
	local tblToSend = WarningSystem7452em:Decompress(tCompressed)

	if not WarningSystem7452em.NetsList[strName] then return end

	if SERVER then
		WarningSystem7452em.NetsList[strName](pSender, tblToSend)
	else
		WarningSystem7452em.NetsList[strName](tblToSend)
	end
end)
