function WarningSystem7452em:Compress( tTable )
	local sJson = util.TableToJSON( tTable or {} )
	local dCompressed = util.Compress( sJson or "" )
	return dCompressed, dCompressed:len()
end

function WarningSystem7452em:Decompress( dData )
	local sJson = util.Decompress( dData )
	local tTable = util.JSONToTable( sJson or "" )
	return tTable
end

function WarningSystem7452em:AddCategory(sID, tCategory)
    WarningSystem7452em.Categories = WarningSystem7452em.Categories or {}

    WarningSystem7452em.Categories[sID] = tCategory
end

function WarningSystem7452em:RegisterThreshold(sID, tTable)
    WarningSystem7452em.Thresholds = WarningSystem7452em.Thresholds or {}

    WarningSystem7452em.Thresholds[sID] = tTable
end

function WarningSystem7452em:Can(pPlayer, sPermission)
    if( pPlayer:IsSuperAdmin() ) then return true end

    local tPermissions = self.CFG.permissions[pPlayer:GetUserGroup()]

    if( not tPermissions ) then return false end

    return tPermissions[sPermission] or false
end

--[[
    Desc: Format Time from 1w 2d 3h for example
    Return: integer
]]

local tTimes = {
    ["s"]  = 1, -- seconds
    ["m"]  = 60, -- minutes
    ["h"]  = 60 * 60, -- hours
    ["d"]  = 60 * 60 * 24, -- days
    ["mo"] = 60 * 60 * 24 * 30, -- months
    ["y"]  = 60 * 60 * 24 * 30 * 12, -- years
}

function WarningSystem7452em:FormatStringToTime(sTime)
    local iTotalTime = 0

    for iValue, sTime in sTime:gmatch("(%d+)(%a+)") do
        if not tTimes[sTime] then continue end
        iTotalTime = iTotalTime + (iValue * tTimes[sTime] or 1) 
    end

    return iTotalTime
end

local tTimesNames = {
    "y", "mo", "d", "h", "m", "s"
}

function WarningSystem7452em:FormatTimeToString(iTime)
    local tUsedTimes = {}

    local iCurrentTime = iTime or 0

    tUsedTimes[6] = iCurrentTime % 60
    iCurrentTime = math.floor( iCurrentTime / 60 )

    tUsedTimes[5] = iCurrentTime % 60
    iCurrentTime = math.floor( iCurrentTime / 60 )

    tUsedTimes[4] = iCurrentTime % 24
    iCurrentTime = math.floor( iCurrentTime / 24 )

    tUsedTimes[3] = iCurrentTime % 30
    iCurrentTime = math.floor( iCurrentTime / 30 )

    tUsedTimes[2] = iCurrentTime % 12
    tUsedTimes[1] = math.floor(iCurrentTime / 12)

    local sTime = ""

    for k, v in ipairs(tUsedTimes) do
        if v == 0 then continue end
        sTime = sTime .. " " .. v .. tTimesNames[k]
    end

    return sTime == "" and "infinite" or string.sub(sTime, 2)
end

function WarningSystem7452em:GetUserGroups()
    if xAdmin then
	    return table.GetKeys(xAdmin.Groups)	
    end
	
    if CAMI then
        return table.GetKeys(CAMI.GetUsergroups())
    end

    if ULib then
        return table.GetKeys(ULib.ucl.groups)
    end

    if FAdmin then
        return table.GetKeys(FAdmin.Access.Groups)
    end

    return {}
end

function WarningSystem7452em:RGBToHex(rgb)
    local charset = {"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"}
    local tmp = {}
    local sHex = ""

    rgb.a = nil

    for k,v in SortedPairs(rgb or {}, true) do
        repeat
            table.insert(tmp, 1, charset[v % 16 + 1])
            v = math.floor(v / 16)
        until v == 0

        sHex = sHex .. table.concat(tmp)
        tmp = {}
    end

    return sHex
end
