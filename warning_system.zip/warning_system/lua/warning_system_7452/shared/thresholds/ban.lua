local THRESHOLD = {}

THRESHOLD.Name = "Ban"

THRESHOLD.Params = {
    { name = "reason", type = "string" },
    { name = "duration", type = "time" }
}

function THRESHOLD:Execute(pPlayer, ...)
    local tParams = {...}
    local sReason = tParams[1]
    local iDuration = tParams[2]

    if( ULib ) then
        ULib.ban(pPlayer, iDuration / 60, sReason)
    elseif( serverguard ) then
        pPlayer:Ban(iDuration / 60, true, sReason)
    elseif( xAdmin ) then
        xAdmin.Admin.RegisterBan(pPlayer, nil, sReason, iDuration / 60)
    elseif( SAM ) then
        pPlayer:sam_ban(iDuration / 60, sReason, pPlayer:SteamID())
    else
        pPlayer:Ban(iDuration / 60, true)
    end
end

WarningSystem7452em:RegisterThreshold("ban", THRESHOLD)