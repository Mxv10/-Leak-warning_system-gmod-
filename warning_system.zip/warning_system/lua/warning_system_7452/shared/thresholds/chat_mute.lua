if( not ulx or not FAdmin ) then return end

local THRESHOLD = {}

THRESHOLD.Name = "Chat Mute"

THRESHOLD.Params = {
    { name = "duration", type = "time" },
}

function THRESHOLD:Can()
    return ulx or FAdmin 
end

function THRESHOLD:Execute(pPlayer, ...)
    if( not self:Can() ) then return end

    local tParams = {...}
    local iDuration = tParams[1]

    if( ulx ) then
        RunConsoleCommand("ulx", "mute", "$" .. pPlayer:SteamID(), iDuration)
    
        timer.Create("WarningSystem7452em:Mute:" .. pPlayer:SteamID(), iDuration, 1, function()
            if( not IsValid(pPlayer) ) then return end

            RunConsoleCommand("ulx", "unmute", "$" .. pPlayer:SteamID())
        end)
    elseif ( FAdmin ) then
        RunConsoleCommand("_FAdmin", "mute", pPlayer:UserID(), iDuration)
        
        timer.Create("WarningSystem7452em:Mute:" .. pPlayer:SteamID(), iDuration, 1, function()
            if( not IsValid(pPlayer) ) then return end

            RunConsoleCommand("_FAdmin", "unmute", "$" .. pPlayer:SteamID())
        end)
    end
end

WarningSystem7452em:RegisterThreshold("chat_mute", THRESHOLD)