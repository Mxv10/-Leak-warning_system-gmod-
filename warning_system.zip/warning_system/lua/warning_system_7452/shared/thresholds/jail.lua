local THRESHOLD = {}

THRESHOLD.Name = "Jail"

THRESHOLD.Params = {
    { name = "duration", type = "time" },
}

function THRESHOLD:Can()
    return ulx or FAdmin 
end

function THRESHOLD:Execute(pPlayer, ...)
    if( not self:Can() ) then return end
    
    local tParams = {...}
    local iDuration = tParams[1]

    if( ulx ) then
        RunConsoleCommand("ulx", "jail", "$" .. pPlayer:SteamID(), iDuration)
    elseif ( FAdmin ) then
        RunConsoleCommand("_FAdmin", "jail", pPlayer:UserID(), iDuration)
    end
end

WarningSystem7452em:RegisterThreshold("jail", THRESHOLD)