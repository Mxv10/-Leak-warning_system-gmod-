local THRESHOLD = {}

THRESHOLD.Name = "DarkRP - Remove Money"

THRESHOLD.Params = {
    { name = "amount", type = "int" },
}

function THRESHOLD:Can()
    return DarkRP
end

function THRESHOLD:Execute(pPlayer, ...)
    if( not self:Can() ) then return end
    
    local tParams = {...}
    local iAmount = tParams[1]

    pPlayer:addMoney(- iAmount)
end

WarningSystem7452em:RegisterThreshold("darkrp_remove_money", THRESHOLD)