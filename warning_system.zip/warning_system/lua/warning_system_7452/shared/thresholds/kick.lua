local THRESHOLD = {}

THRESHOLD.Name = "Kick"

THRESHOLD.Params = {
    { name = "reason", type = "string" },
}

function THRESHOLD:Execute(pPlayer, ...)
    local tParams = {...}
    local sReason = tParams[1]

    pPlayer:Kick(sReason)
end

WarningSystem7452em:RegisterThreshold("Kick", THRESHOLD)