resource.AddFile("resource/fonts/Poppins-Bold.ttf")
resource.AddFile("resource/fonts/Poppins-Medium.ttf")
resource.AddFile("resource/fonts/Poppins-Regular.ttf")
resource.AddFile("resource/fonts/Poppins-SemilBold.ttf")

resource.AddFile("materials/warning_system/chart.png")
resource.AddFile("materials/warning_system/cog.png")
resource.AddFile("materials/warning_system/search.png")
resource.AddFile("materials/warning_system/user.png")
resource.AddFile("materials/warning_system/warning.png")
resource.AddFile("materials/warning_system/cross.png")
resource.AddFile("materials/warning_system/arrow_forward.png")
resource.AddFile("materials/warning_system/calendar.png")
resource.AddFile("materials/warning_system/error.png")

concommand.Add("warning_system_import_awarn3", function(pPlayer, _, tArgs)
    if( pPlayer and IsValid(pPlayer) ) then
        if( not pPlayer:IsSuperAdmin() ) then return end
    end

    local iPenalty = 0

    if( tArgs[1] and tonumber(tArgs[1]) ) then
        iPenalty = tonumber(tArgs[1])
    end

    WarningSystem7452em.SQL:ImportAWarn3(pPlayer, iPenalty)

    print("[Warning System] - " .. WarningSystem7452em:__("awarn_imported"))
end)

concommand.Add("warning_system_reset", function(pPlayer, _, tArgs)
    if( pPlayer and IsValid(pPlayer) ) then
        if( not pPlayer:IsSuperAdmin() ) then return end
    end

    if( tArgs[1] ) then
        local sType = tArgs[1]

        if( sType == "warnings" ) then
            WarningSystem7452em.SQL:Query("DROP TABLE ws_warns")
        end

        if( sType == "configuration" ) then
            WarningSystem7452em.SQL:Query("DROP TABLE ws_settings")
        end

        if( sType == "notes" ) then
            WarningSystem7452em.SQL:Query("DROP TABLE ws_players")
        end
        
        print("[Warning System] - [Reset] : " .. sType .. " rested!")
    else
        WarningSystem7452em.SQL:Query("DROP TABLE ws_players")
        WarningSystem7452em.SQL:Query("DROP TABLE ws_settings")
        WarningSystem7452em.SQL:Query("DROP TABLE ws_thresholds")
        WarningSystem7452em.SQL:Query("DROP TABLE ws_warns")
        
        print("[Warning System] - [Reset] : All rested!")
    end

    WarningSystem7452em.SQL:onConnected()
end)