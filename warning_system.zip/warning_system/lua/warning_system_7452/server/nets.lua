WarningSystem7452em:NetReceive("WarningSystem7452em:Player:Warn", function(pPlayer, tInfo)
    if( not WarningSystem7452em:Can(pPlayer, "add_warn") ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.no_access"))
    end

    if( string.len(tInfo.reason) <= 0 ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.reason_too_short"))
    end

    if( string.len(tInfo.reason) > 255 ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.reason_too_long"))
    end
    
    if( not tInfo.penalty or not tonumber(tInfo.penalty) ) then
        tInfo.penalty = 0
    end

    local iExpires_at = nil

    if( tInfo.duration and tostring(tInfo.duration) ~= "0" ) then
        iExpires_at = os.time() + tInfo.duration
    end

    local bHappened = WarningSystem7452em:Warn(tInfo.target, pPlayer, tInfo.reason, tInfo.penalty, iExpires_at)

    if not bHappened then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.no_access"))
    end

    local pVictim = player.GetBySteamID64(tInfo.target)

    if( not IsValid(pVictim) ) then
        pVictim = tInfo.target
    else
        WarningSystem7452em:Notify(pVictim, 2, WarningSystem7452em:__("youve_been_warned"))
        pVictim = pVictim:Nick()
    end

    tInfo.victim = pVictim

    hook.Run("WarningSystem7452em:Player:Warn", pPlayer, tInfo)

    return WarningSystem7452em:Notify(pPlayer, 0, WarningSystem7452em:__("player_been_warned"))
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:UnWarn", function(pPlayer, tInfo)
    if( not WarningSystem7452em:Can(pPlayer, "remove_warn") ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.no_access"))
    end

    WarningSystem7452em:UnWarn(tInfo.id)

    local pVictim = player.GetBySteamID64(tInfo.target)

    if( not IsValid(pVictim) ) then
        pVictim = tInfo.target
    else
        pVictim = pVictim:Nick()
    end

    hook.Run("WarningSystem7452em:Player:UnWarn", pPlayer, { victim = pVictim })

    return WarningSystem7452em:Notify(pPlayer, 0, WarningSystem7452em:__("player_been_unwarned"))
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:UpdateNote", function(pPlayer, tInfo)
    if( not WarningSystem7452em:Can(pPlayer, "edit_note") ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.no_access"))
    end

    WarningSystem7452em:Note(tInfo.target, tInfo.note)
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:UpdateSettings", function(pPlayer, tInfo)
    if( not WarningSystem7452em:Can(pPlayer, "edit_settings") ) then
        return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.no_access"))
    end

    WarningSystem7452em.CFG =  WarningSystem7452em.CFG or {}

    if( not tInfo.keys ) then
        if( not tInfo.key || string.len(tInfo.key) <= 0 ) then
            return WarningSystem7452em:Notify(pPlayer, 1, WarningSystem7452em:__("errors.invalid_key"))
        end

        if( tInfo.key == "reasons" ) then
            if( 
                not tInfo.removeId and
                ( not tInfo.value 
                or not tInfo.value.reason 
                or not tInfo.value.penalty )  
            ) then return end

            WarningSystem7452em.CFG.reasons = WarningSystem7452em.CFG.reasons or {}
            
            if( tInfo.removeId ) then
                WarningSystem7452em.CFG.reasons[tInfo.removeId] = nil
            else
                table.insert(WarningSystem7452em.CFG.reasons, tInfo.value)
            end

            WarningSystem7452em:SendConfig(nil, "reasons")
        end

        if( tInfo.key == "theme" ) then
            WarningSystem7452em.CFG.theme = tInfo.value
        end

        if( tInfo.key == "permissions" ) then
            WarningSystem7452em.CFG.permissions = tInfo.value
            WarningSystem7452em:SendConfig(nil, "permissions")
        end

        if( tInfo.key == "threshold" ) then
            WarningSystem7452em.CFG.thresholds = WarningSystem7452em.CFG.thresholds or {}

            if( tInfo.removeId ) then
                WarningSystem7452em.CFG.thresholds[tInfo.removeId] = nil
            else
                tInfo.value["uniqueId"] = os.time()

                table.insert(WarningSystem7452em.CFG.thresholds, tInfo.value)
            end
        end
    else
        for k,v in pairs(tInfo.keys or {}) do
            WarningSystem7452em.CFG[k] = v
        end
    end

    WarningSystem7452em:SaveSettings()

    return WarningSystem7452em:Notify(pPlayer, 0, WarningSystem7452em:__("settings_updated"))
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:GetInfo", function(pPlayer, tInfo)
    local sTarget = tInfo.target

    if( not sTarget ) then return end

    local tInfos = {
        ["warnings"] = function(pPlayer, sTarget)
            return sTarget == pPlayer:SteamID64() or WarningSystem7452em:Can(pPlayer, "view_others_warnings")
        end,

        ["note"] = function(pPlayer, sTarget)
            return WarningSystem7452em:Can(pPlayer, "view_note")
        end,

        ["fetch_penalty_points"] = function(pPlayer, sTarget)
            return WarningSystem7452em:Can(pPlayer, "view_others_warnings")
        end,

        ["settings"] = function(pPlayer, sTarget)
            return WarningSystem7452em:Can(pPlayer, "edit_settings")
        end,

        ["stats"] = function(pPlayer, sTarget)
            return WarningSystem7452em:Can(pPlayer, "view_stats")
        end,
    }

    if( tInfo.types ) then
        local tResults = {}
    
        for k,v in ipairs(tInfo.types or {}) do
            if( tInfos[v](pPlayer, sTarget) ) then
                WarningSystem7452em:GetInfo(v, sTarget, function(result)
                    tResults[v] = result

                    if v == "warnings" and not result then tResults[v] = {} end
                end)
            end
        end

        WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", { type = tInfo.type, results = tResults, target = sTarget }, pPlayer)
    else
        if( tInfos[tInfo.type](pPlayer, sTarget) ) then
            WarningSystem7452em:GetInfo(tInfo.type, sTarget, function(result)
                WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", { type = tInfo.type, result = result, target = sTarget }, pPlayer)
            end)
        end
    end
end)
