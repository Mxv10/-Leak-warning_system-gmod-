// gmod dirty hack from wiki...
hook.Add( "PlayerInitialSpawn", "WarningSystem7452em:PlayerInitialSpawn", function( pPlayer )
    hook.Add( "SetupMove", pPlayer, function(self, pPlayer, _, cmd )
        if self == pPlayer and not cmd:IsForced() then hook.Run("PlayerFullLoad", self) hook.Remove("SetupMove", self) end
    end)
end)

hook.Add("PlayerFullLoad", "WarningSystem7452em:PlayerFullLoad", function(pPlayer)
    if ( pPlayer:IsBot() ) then return end
        
    WarningSystem7452em:SendConfig(pPlayer, "theme")
    WarningSystem7452em:SendConfig(pPlayer, "reasons")
    WarningSystem7452em:SendConfig(pPlayer, "permissions")
    WarningSystem7452em:CheckThresholds(pPlayer:SteamID64())

    local tWarnings = {}

    WarningSystem7452em:GetInfo("warnings", pPlayer:SteamID64(), function(tRes)
        if tRes then
            tWarnings = tRes
        end
    end)
    
    local iWarnings = table.Count(tWarnings or {}) or 0

    if iWarnings > 0 then
        for k,v in ipairs(player.GetAll()) do
            if( v == pPlayer ) then continue end
            
            if( WarningSystem7452em:Can(v, "view_others_warnings") ) then
                WarningSystem7452em:Notify(pPlayer, 0, WarningSystem7452em:__("joins_with_x"):format(pPlayer:Nick(), iWarnings))
            end
        end
    end
end)

hook.Add("PlayerSay", "WarningSystem7452em:PlayerSay", function(pPlayer, sText)
    if string.match(sText, "^([!/]" .. WarningSystem7452em.CFG.ChatCommand .. ")$") then
        WarningSystem7452em:SendConfig(pPlayer, "theme")
        WarningSystem7452em:NetStart("open_menu", {}, pPlayer)

        return ""
    end
end)

hook.Add("WarningSystem7452em:SQL:Connected", "WarningSystem7452em:SQL:Connected", function()
    if( WarningSystem7452em.SQL ) then
        WarningSystem7452em:SyncConfig()
    else
        timer.Create("WarningSystem7452em:SQL:Connected", 5, 0, function()
            if( WarningSystem7452em.SQL ) then
                WarningSystem7452em:SyncConfig()
                timer.Destroy("WarningSystem7452em:SQL:Connected")
            end
        end)
    end
end)