WarningSystem7452em.Steam = WarningSystem7452em.Steam or {}
WarningSystem7452em.Steam.Users = {}

WarningSystem7452em.Steam.Urls = {
    getPlayerSummaries = "http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=%s&steamids=%s"
}

function WarningSystem7452em.Steam:GetInfo(tSteamids, fnCallback)
    local tRes = {}
    local tToFinds = {}

    for k,v in ipairs(tSteamids or {}) do
        local sKey = tostring(v) .. "_"
        local tInfo = WarningSystem7452em.Steam.Users[sKey]

        if( tInfo ) then
            tRes[sKey] = {
                avatar = tInfo.avatar,
                name = tInfo.name,
                steamid = v
            }         
         
            continue 
        end

        if( table.HasValue(tToFinds, v) ) then continue end

        tRes[sKey] = {
            avatar = "",
            name = "Unknown",
            steamid = v
        }        

        table.insert(tToFinds, v)
    end

    if( table.Count(tToFinds) < 1 ) then 
        if( fnCallback ) then
            return fnCallback(tRes)
        end
    end

    local sUrl = WarningSystem7452em.Steam.Urls.getPlayerSummaries:format(WarningSystem7452em.CFG.SteamApiKey, string.Implode(",", tToFinds))

    http.Fetch(sUrl, function(body)
        if( not string.StartWith(body, "{") ) then return end

        local json = util.JSONToTable(body)
        local response = json["response"]

        if( not response ) then return end

        local players = response["players"]

        if( not players ) then return end

        for k,v in ipairs(players or {}) do
            tRes[tostring(v.steamid) .. "_"].name = v.personaname
            tRes[tostring(v.steamid) .. "_"].avatar = v.avatar
        end

        WarningSystem7452em.Steam.Users = table.Merge(WarningSystem7452em.Steam.Users, tRes)

        if( fnCallback ) then
            return fnCallback(tRes)
        end
    end, function(err)
        print("[Warning System] - [Steam] : ", err)
    end)
end