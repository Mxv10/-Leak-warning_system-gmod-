--[[
    Desc: Send config to client
    Return: nil
]]--

function WarningSystem7452em:SendConfig(pPlayer, sKey)
    local t = table.Copy(self.CFG)

    if( sKey ) then
        t = t[sKey]
    end

    t["SteamApiKey"] = nil
    t["DiscordWebhook"] = nil

    WarningSystem7452em:NetStart("sync_settings", { value = t, key = sKey }, pPlayer or nil)
end

--[[  
    Desc : Sync configuration with database
    Return : boolean
]]

function WarningSystem7452em:SyncConfig()
    local q = WarningSystem7452em.SQL:Query("SELECT * FROM ws_settings")
    local tConfig = {}

    for k,v in ipairs(q or {}) do
        value = v.value

        if( string.StartWith(value, "{") or string.StartWith(value, "[") ) and v.key ~= "NotWarnable" then
            value = util.JSONToTable(value or "{}")
        end

        tConfig[v.key] = value
    end

    WarningSystem7452em.CFG = tConfig

    return true
end

--[[  
    Desc : Warn a player
    Return : boolean
]]

function WarningSystem7452em:Warn(sSteamID64, pAdmin, sReason, iPenalty, sExpiresAt)
    if WarningSystem7452em:GetNonWarnable(sSteamID64) then
        return false
    end

    local sAdminName = "[CONSOLE]"
    local sAdminID = "[CONSOLE]"

    if( not isstring(pAdmin) and IsValid(pAdmin) ) then
        sAdminName = pAdmin:Nick()
        sAdminID = pAdmin:SteamID64()
    elseif( isstring(pAdmin) ) then
        sAdminID = pAdmin
    end

    local q = self.SQL:Query("INSERT INTO ws_warns(steamid, administrator, administrator_steamid, reason, penalty, created_at, expires_at) VALUES(?, ?, ?, ?, ?, ?, ?)", {
        sSteamID64,
        sAdminName,
        sAdminID,
        sReason,
        iPenalty,
        os.time(),
        sExpiresAt
    })

    self:CheckPenalty(sSteamID64)

    return true
end

--[[
    desc: Unwarn a player
    Return: boolean
]]--

function WarningSystem7452em:UnWarn(iID)
    self.SQL:Query("DELETE FROM ws_warns WHERE id = ?", { iID })

    return true
end

--[[  
    Desc : Update a specific setting
    Return : boolean
]]

function WarningSystem7452em:UpdateSetting(sKey, sValue)
    if( not sValue ) then
        WarningSystem7452em.SQL:Query("DELETE FROM ws_settings WHERE `key` = ?", { sKey })
        return true
    end

    if( istable(sValue) ) then
        sValue = util.TableToJSON(sValue)
    end

    local q = self.SQL:Query("SELECT COUNT(*) AS amount FROM ws_settings WHERE `key` = ? LIMIT 1", { sKey })

    if( q and q[1] and tostring(q[1].amount) != "0" ) then
        self.SQL:Query("UPDATE ws_settings SET `value` = ? WHERE `key` = ?", { sValue, sKey })
    else
        self.SQL:Query("INSERT INTO ws_settings(`key`, `value`) VALUES(?, ?)", { sKey, sValue })
    end

    return true
end

--[[  
    Desc : Get a specific image of player
    Return : any
]]

function WarningSystem7452em:GetInfo(sType, sTarget, fnCallback)
    if( sType == "warnings" ) then
        local q = self.SQL:Query("SELECT * FROM ws_warns WHERE steamid = ?", {sTarget})
        return fnCallback(q)
    end

    if( sType == "note" ) then
        local q = self.SQL:Query("SELECT note FROM ws_players WHERE steamid = ? LIMIT 1", {sTarget})
        
        if( q and q[1] ) then
            return fnCallback(q[1].note)
        end

        return fnCallback("")
    end

    if( sType == "fetch_penalty_points" ) then
        return fnCallback(WarningSystem7452em:FetchPenaltyPoints())
    end

    if( sType == "settings" ) then
        return fnCallback(self.CFG)
    end

    if( sType == "stats"  ) then
        self.Stats = self.Stats or {}

        if( (not self.Stats or not self.Stats.last_cache) or (os.time() > self.Stats.last_cache) ) then
            local tWarnings = self.SQL:Query("SELECT * FROM ws_warns ORDER BY id DESC")
            local iPenaltyPoints = 0
            local iMonthly_warnings = 0
            local tGraph = {}

            for i = 1, 12 do
                tGraph[i] = 0
            end

            for k,v in ipairs(tWarnings or {}) do
                local sCurrentYear = os.date("%Y", os.time())
                local sCurrentMonth = os.date("%m", os.time())

                local sYearCAT = os.date("%Y", tonumber(v.created_at)) 
                local iCurrentMonth = tonumber(sCurrentMonth)

                if( sYearCAT == sCurrentYear ) then
                    tGraph[iCurrentMonth] = tGraph[iCurrentMonth] + 1 
                end

                if( v.expires_at and v.expires_at ~= "NULL" ) then

                    local sYear = os.date("%Y", tonumber(v.expires_at)) 
                    local sMonth = os.date("%m", tonumber(v.expires_at))
                    
                    if( sYear == sCurrentYear and sMonth == sCurrentMonth ) then
                        iMonthly_warnings = iMonthly_warnings + 1
                    end

                    if( tonumber(v.expires_at) > os.time() ) then
                        iPenaltyPoints = iPenaltyPoints + v.penalty
                    end
                else
                    iPenaltyPoints = iPenaltyPoints + v.penalty
                end
            end

            local tLastWarnings = {unpack(tWarnings or {}, 1, 5)}
            local tMostWarned = self.SQL:Query("SELECT COUNT(*) as amount, steamid FROM ws_warns GROUP BY steamid ORDER BY amount DESC LIMIT 5")
            local tStaffLeaderboard = self.SQL:Query("SELECT COUNT(*) as amount, administrator_steamid as steamid FROM ws_warns GROUP BY administrator_steamid ORDER BY amount DESC LIMIT 5")

            self.Stats = {
                total_warnings = table.Count(tWarnings or {}),
                total_penalty_points = iPenaltyPoints,
                monthly_warnings = iMonthly_warnings,

                last_warnings = tLastWarnings,
                most_warned = tMostWarned,
                staff_leaderboards = tStaffLeaderboard,

                graph = tGraph,

                last_cache = os.time() + 60
            }
        end

        if( self.CFG.SteamApiKey and string.len(self.CFG.SteamApiKey) > 5 ) then
            self.Stats.apiKey = true

            local tSteamIDs = {}

            for k,v in ipairs(self.Stats.last_warnings or {}) do
                tSteamIDs[v.steamid] = true
            end

            for k,v in ipairs(self.Stats.most_warned or {}) do
                tSteamIDs[v.steamid] = true
            end

            for k,v in ipairs(self.Stats.staff_leaderboards or {}) do
                if( string.StartWith(v.steamid, "76") ) then
                    tSteamIDs[v.steamid] = true
                end
            end

            local tToFinds = table.GetKeys(tSteamIDs)

            self.Stats.users = nil

            WarningSystem7452em.Steam:GetInfo(tToFinds, function(tRes)
                self.Stats = table.Merge(self.Stats, { users = tRes })
            
                fnCallback(self.Stats)
            end)        
        else
            self.Stats.apiKey = false

            return fnCallback(self.Stats)
        end
    end
end

--[[  
    Desc : Check penalty sanction of player
    Return : nil
]]

function WarningSystem7452em:CheckPenalty(sSteamID64)
    local tWarnings = {}
    
    self:GetInfo("warnings", sSteamID64, function(tResult)
        tWarnings = tResult
    end)

    local iPenalty = 0

    for k,v in ipairs(tWarnings or {}) do
        if( v.expires_at and v.expires_at ~= "NULL" ) then
            if( tonumber(v.expires_at) > os.time() ) then
                iPenalty = iPenalty + v.penalty
            end
        else
            iPenalty = iPenalty + v.penalty
        end
    end 

    local iPenaltyBefore = iPenalty
    iPenaltyBefore = iPenaltyBefore - tWarnings[#tWarnings].penalty

    local tThresholds = {}
    local tThresoldsDB = self.SQL:Query("SELECT uniqueId FROM ws_thresholds WHERE steamid = ? AND done = 0", { sSteamID64 })
    local tUniqueIds = {}

    for k,v in ipairs(tThresoldsDB or {}) do
        tUniqueIds[tostring(v.uniqueId)] = true
    end

    for k,v in pairs(self.CFG.thresholds or {}) do
        if( v.penalty <= iPenalty and v.penalty > iPenaltyBefore and not tUniqueIds[tostring(v.uniqueId)] ) then
            table.insert(tThresholds, v)
        end
    end

    if( table.Count(tThresholds) > 0 ) then
        for k,v in ipairs(tThresholds or {}) do
            self.SQL:Query("INSERT INTO ws_thresholds(steamid, uniqueId, done, created_at) VALUES(?, ?, ?, ?)", {
                sSteamID64,
                v.uniqueId,
                0,
                os.time()
            })
        end
    end

    self:CheckThresholds(sSteamID64)
end

--[[
    Desc: Checking the player's thresholds
    Return: nil
]]--

function WarningSystem7452em:CheckThresholds(sSteamID64)
    local pPlayer = player.GetBySteamID64(sSteamID64)

    if( not pPlayer or not IsValid(pPlayer) ) then return end

    local tThresoldsDB = self.SQL:Query("SELECT id, uniqueId FROM ws_thresholds WHERE steamid = ? AND done = 0", { sSteamID64 })

    local tThresholds = {}

    for k,v in ipairs(tThresoldsDB or {}) do
        local tConfigThreshold = self:GetThresholdByUniqueId(v.uniqueId)

        if( not tConfigThreshold ) then continue end
    
        table.insert(tThresholds, tConfigThreshold)
    end

    for k,v in ipairs(tThresholds or {}) do
        local t = self.Thresholds[v.name]

        if( not t ) then continue end

        if( t.Can and not t.Can() ) then continue end

        t:Execute(pPlayer, unpack(v.params))

        self.SQL:Query("UPDATE ws_thresholds SET done = 1 WHERE steamid = ? AND uniqueId = ?", {
            sSteamID64,
            v.uniqueId
        })
    end
end

--[[
    Desc: Get threshold by unique id
    Return: Array
]]--

function WarningSystem7452em:GetThresholdByUniqueId(sID)
    local tThreshold = false


    for k,v in pairs(self.CFG.thresholds or {}) do
        if( tostring(v.uniqueId) == tostring(sID) ) then
            tThreshold = v
            break 
        end
    end

    return tThreshold
end

--[[
    Desc: Update player note
    Return: boolean
]]--

function WarningSystem7452em:Note(sSteamID, sNote)
    local q = self.SQL:Query("SELECT COUNT(*) as amount FROM ws_players WHERE steamid = ? LIMIT 1", { sSteamID })

    if( q and q[1] and tostring(q[1].amount) ~= "0" ) then
        if( not sNote || string.len(sNote) < 1 ) then
            self.SQL:Query("DELETE FROM ws_players WHERE steamid = ?", { sSteamID })
        else
            self.SQL:Query("UPDATE ws_players SET note = ? WHERE steamid = ?", { sNote, sSteamID })
        end
    else
        if( sNote and string.len(sNote) > 0 ) then
            self.SQL:Query("INSERT INTO ws_players(steamid, note) VALUES(?, ?)", { sSteamID, sNote })
        end
    end

    return true
end

--[[
    Desc: Get all penalty points
    Return: Array
]]--

function WarningSystem7452em:FetchPenaltyPoints()
    local tIn = {}

    for k,v in ipairs(player.GetAll() or {}) do
        table.insert(tIn, v:SteamID64())
    end

    local sIn = "(" .. table.concat(tIn, ",") .. ")"

    local q = WarningSystem7452em.SQL:Query([[
        SELECT SUM(penalty) as total, steamid
        FROM ws_warns 
        WHERE (expires_at IS NULL or expires_at > ?) AND steamid IN ]] .. sIn .. [[
        GROUP BY steamid
    ]], { os.time() })

    local tResults = {}

    for k,v in ipairs(q or {}) do
        tResults[tostring(v.steamid) .. "_"] = v.total
    end

    return tResults
end

--[[
    Desc: Save current settings
    Return: boolean
]]--

function WarningSystem7452em:SaveSettings()
    for k,v in pairs(self.CFG or {}) do
        self:UpdateSetting(k, v)
    end 
end

--[[
    Desc: Notify a player
    Return: boolean
]]--

function WarningSystem7452em:Notify(pPlayer, iType, sMsg, iLength)
    if( not pPlayer or not IsValid(pPlayer) ) then return false end

    self:NetStart("WarningSystem7452em:Player:Notify", {
        iType = iType,
        msg = sMsg,
        iLength = iLength or 5
    }, pPlayer)

    return true
end

--[[
    Desc: Check if sID is non-warnable
    Return: table
]]--

function WarningSystem7452em:GetNonWarnable(sID)
    return string.find(WarningSystem7452em.CFG["NotWarnable"], sID) ~= nil
end