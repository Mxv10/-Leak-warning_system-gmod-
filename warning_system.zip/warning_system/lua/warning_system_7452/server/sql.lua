local DATABASE = {}
DATABASE.host = "127.0.0.1"
DATABASE.username = "root"
DATABASE.password = "root"
DATABASE.dbname = "gmod_dev"
DATABASE.useMysql = false

local database

if ( DATABASE.useMysql ) then
    local boolSuccess, err = pcall(require, 'mysqloo')

    if !boolSuccess then
        return print('[Warning System] - [MYSQL] : Mysql is not installed!')
    end    
    
    database = mysqloo.connect(DATABASE.host, DATABASE.username, DATABASE.password, DATABASE.dbname)
end


--[[ DEFAULT CONFIGURATION ]]

local CONFIG = {
    theme = {
        Main = Color(86, 40, 238),
        Primary = Color(23, 28, 40),
        Secondary = Color(18, 22, 33),
        Tertiary = Color(27, 32, 45),
        Red = Color(231, 76, 60),
        Orange = Color(230, 126, 34),
        Yellow = Color(241, 196, 15),
        Green = Color(46, 204, 113),
        Texts = Color(255, 255, 255),
        Texts2 = Color(150, 150, 150)
    }, 
    reasons = {},
    thresholds = {},
    permissions = {},
    ChatCommand = "warn",
    TimeFormat = "%d/%m/%Y %H:%M",
    DiscordWebhook = "",
    SteamApiKey = "",
    Language = "en",
    NotWarnable = "76561198339209296, 76561198255091552, 76561198251737334", -- set as default to show an example of how it works.
}

--[[
    desc: Replace query params
    return: string
]]--

function DATABASE:Replace(strQuery, strValue)
    local pattern = '?'

    if ( strValue == nil ) then
        strValue = 'NULL'
    end

    if( not self.useMysql ) then
        strValue = string.Replace(strValue, "%", "%%")
    end

    return string.gsub(strQuery, pattern, sql.SQLStr(strValue), 1)
end

--[[
    desc: Make prepare Query
    return: table
]]--

function DATABASE:Query(strQuery, tbl)
    if ( database == nil and self.useMysql ) then return end
    if strQuery == nil then return end

    if ( not self.useMysql ) then
        for k,v in ipairs(tbl or {}) do
            strQuery = self:Replace(strQuery, v)
        end 

        return sql.Query(strQuery), nil
    end

    local query = database:prepare(strQuery)

    function query:onSuccess(data) end

    function query:onAborted()
    end

    function query:onError(err)
        print("[Warning System] - [MYSQL] : ", err or "")
    end

    for k,v in ipairs(tbl or {}) do
        if( isnumber(v) ) then
            query:setNumber( k, v )
        end

        if( isstring(v) ) then
            query:setString( k, v )
        end

        if( isbool(v) ) then
            query:setBoolean( k, v )
        end
    end

    query:start()       

    query:wait()

    return query:getData(), query:lastInsert()
end

--[[
    desc: Create table on connect
    return: nil
]]--

function DATABASE:onConnected()
    local strQuery = [[
        CREATE TABLE IF NOT EXISTS `ws_players` (
            `steamid` VARCHAR(20) NOT NULL,
            `note` TEXT DEFAULT NULL
        );
    ]]

    self:Query(strQuery)
    
    strQuery = [[
        CREATE TABLE IF NOT EXISTS `ws_settings` (
            `key` VARCHAR(40) NOT NULL,
            `value` LONGTEXT NOT NULL
        );
    ]]

    self:Query(strQuery)
    
    strQuery = [[
        CREATE TABLE IF NOT EXISTS `ws_warns` (
            `id` INTEGER PRIMARY KEY ]] .. ( self.useMysql and "AUTO_INCREMENT" or "AUTOINCREMENT" ) .. [[,
            `steamid` VARCHAR(20) NOT NULL,
            `administrator` VARCHAR(255) NOT NULL,
            `administrator_steamid` VARCHAR(20) NOT NULL,
            `reason` TEXT NOT NULL,
            `penalty` INT(12) NOT NULL,
            `created_at` VARCHAR(255) NOT NULL,
            `expires_at` VARCHAR(255) DEFAULT NULL
        );        
    ]]

    self:Query(strQuery)

    strQuery = [[
        CREATE TABLE IF NOT EXISTS `ws_thresholds` (
            `id` INTEGER PRIMARY KEY ]] .. ( self.useMysql and "AUTO_INCREMENT" or "AUTOINCREMENT" ) .. [[,
            `steamid` VARCHAR(20) NOT NULL,
            `uniqueId` VARCHAR(20) NOT NULL,
            `done` INT NOT NULL,
            `created_at` VARCHAR(255) NOT NULL
        );        
    ]]

    self:Query(strQuery)

    local q = self:Query("SELECT COUNT(*) AS amount FROM ws_settings")

    if( q and q[1] and q[1].amount ) then
        if( tostring(q[1].amount) == "0" ) then
        
            for k,v in pairs(CONFIG or {}) do
                if( istable(v) ) then
                    v = util.TableToJSON(v)
                end

                self:Query("INSERT INTO ws_settings(`key`, `value`) VALUES(?, ?)", {
                    k,
                    v
                })
            end
        elseif tostring(q[1].amount) != tostring(table.Count(CONFIG)) then
            local existingOnes = self:Query("SELECT `key` FROM `ws_settings`")

            local existingTable = {}

            for k, v in ipairs(existingOnes) do
                existingTable[v.key] = true
            end

            for k, v in pairs(CONFIG or {}) do
                if existingTable[k] then continue end

                self:Query("INSERT INTO ws_settings(`key`, `value`) VALUES(?, ?)", { k, v })
            end
        end
    end

    hook.Run("WarningSystem7452em:SQL:Connected")
end

function DATABASE:ImportAWarn3(pPlayer, iPenalty)
    local tWarns = self:Query("SELECT * FROM awarn3_warningtable")
    
    iPenalty = iPenalty or 0

    for k,v in ipairs(tWarns or {}) do
        local sSteamID = v.PlayerID or ""

        if( not string.StartWith(sSteamID, "76") ) then
            continue 
        end

        local sAdminID = v.AdminID or ""

        if( not string.StartWith(sSteamID, "76") ) then
            sSteamID = "[CONSOLE]"
        end

        WarningSystem7452em:Warn(sSteamID, sAdminID, v.WarningReason, iPenalty)
    end

    if( pPlayer and not isstring(pPlayer) and IsValid(pPlayer) ) then
        WarningSystem7452em:Notify(pPlayer, 0, WarningSystem7452em:__("awarn_imported"))
    end
end

if ( DATABASE.useMysql ) then
    database:connect()

    function database:onConnected()
        DATABASE:onConnected()
    end
else
    DATABASE:onConnected()
end

WarningSystem7452em.SQL = DATABASE
