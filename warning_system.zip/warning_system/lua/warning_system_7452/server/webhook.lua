local boolSuccess, err = pcall(require, 'chttp')

if not boolSuccess then
    return print('[Warning System] - [Discord Webhook] : You need gmod-chttp to enable discord webhook !')
end

local tEmbeds = {
    ["new_warning"] = function(pPlayer, tInfo)
        return {
            {
                title = ":pushpin: " .. WarningSystem7452em:__("webhooks.new_warning"),
                color = tonumber(WarningSystem7452em:RGBToHex(WarningSystem7452em.CFG.theme.Main), 16),
                fields = {
                    {
                        name = ":warning: " .. WarningSystem7452em:__("webhooks.user"),
                        value = tInfo.victim,
                        inline = true
                    },
                    {
                        name = ":scales: " .. WarningSystem7452em:__("webhooks.admin"),
                        value = pPlayer:Nick(),
                        inline = true,
                    },
                    {
                        name = ":paperclip: " .. WarningSystem7452em:__("webhooks.more_info"),
                        value = WarningSystem7452em:FormatTimeToString(tInfo.duration) .. " - " .. tInfo.penalty .. " " .. WarningSystem7452em:__("penalty_points"):lower(),
                        inline = true,
                    },
                    {
                        name = ":clipboard: " .. WarningSystem7452em:__("reason"),
                        value = tInfo.reason,
                    },
                }
            }
        }
    end,
    ["warning_removed"] = function(pPlayer, tInfo)
        return {
            {
                title = ":pushpin: " .. WarningSystem7452em:__("webhooks.warning_removed"),
                color = tonumber(WarningSystem7452em:RGBToHex(WarningSystem7452em.CFG.theme.Main), 16),
                fields = {
                    {
                        name = ":warning: " .. WarningSystem7452em:__("webhooks.user"),
                        value = tInfo.victim,
                        inline = true
                    },
                    {
                        name = ":scales: " .. WarningSystem7452em:__("webhooks.admin"),
                        value = pPlayer:Nick(),
                        inline = true,
                    }
                }
            }
        }
    end,
}

WarningSystem7452em.Discord = WarningSystem7452em.Discord or {}

function WarningSystem7452em.Discord:Send(sType, pPlayer, tInfo)
    if( not WarningSystem7452em.CFG.DiscordWebhook or string.len(WarningSystem7452em.CFG.DiscordWebhook) < 5 ) then return end

    CHTTP({
        url = WarningSystem7452em.CFG.DiscordWebhook,
        method = "POST",
        type = "application/json",
        body = util.TableToJSON({
            content = "",
            embeds =  tEmbeds[sType](pPlayer, tInfo)
        }),
        failed = function(sErr)
            print("[Warning System] - [Discord Webhook] : " .. sErr)
        end,
        success = function(body) end
    })
end

hook.Add("WarningSystem7452em:Player:Warn", "WarningSystem7452em:Discord:Webhook", function(pPlayer, tInfo)
    WarningSystem7452em.Discord:Send("new_warning", pPlayer, tInfo)
end)

hook.Add("WarningSystem7452em:Player:UnWarn", "WarningSystem7452em:Discord:Webhook", function(pPlayer, tInfo)
    WarningSystem7452em.Discord:Send("warning_removed", pPlayer, tInfo)
end)