WarningSystem7452em:NetReceive("sync_settings", function(tConfig)
    WarningSystem7452em.CFG = WarningSystem7452em.CFG or {}

    if( tConfig.key ) then
        WarningSystem7452em.CFG[tConfig.key] = tConfig.value

        if not WarningSystem7452em.CMenuOkay and WarningSystem7452em.CFG.permissions then
            if WarningSystem7452em:Can(LocalPlayer(), "add_warn") or WarningSystem7452em:Can(LocalPlayer(), "view_others_warnings") then
                WarningSystem7452em:InitContextMenu()
            end
        end
    else
        WarningSystem7452em.CFG = tConfig.value
    end
end)

WarningSystem7452em:NetReceive("open_menu", function()
    WarningSystem7452em:OpenMenu()
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:GetInfo", function(tInfo)
    if( tInfo.target ~= "null" ) then
        WarningSystem7452em.Users[tInfo.target] = WarningSystem7452em.Users[tInfo.target] or {}

        if( tInfo.type == "warnings" ) then
            WarningSystem7452em.Users[tInfo.target].warnings = tInfo.result
            hook.Run("WarningSystem7452em:Player:InfoReceived", "warnings")
        end

        if( tInfo.type == "note" ) then
            WarningSystem7452em.Users[tInfo.target].note = tInfo.result
            hook.Run("WarningSystem7452em:Player:InfoReceived", "note")
        end

        for k,v in pairs(tInfo.results or {}) do
            WarningSystem7452em.Users[tInfo.target][k] = v
        end
    end

    if( tInfo.type == "fetch_penalty_points" ) then
        WarningSystem7452em.PenaltyPoints = tInfo.result
    end

    if( tInfo.type == "settings" ) then
        WarningSystem7452em.CFG = tInfo.result
    end

    if( tInfo.type == "stats" ) then
        WarningSystem7452em.Stats = tInfo.result
    end

    if IsValid(WarningSystem7452em.Menu) then
        WarningSystem7452em.Menu:StopLoading()
    end
end)

WarningSystem7452em:NetReceive("WarningSystem7452em:Player:Notify", function(tInfo)
    WarningSystem7452em:Notify(tInfo.iType, tInfo.msg, tInfo.iLength)
end)