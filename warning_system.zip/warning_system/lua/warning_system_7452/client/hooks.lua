hook.Add( "OnScreenSizeChanged", "WarningSystem7452em:OnScreenSizeChanged", function()
    if IsValid(WarningSystem7452em.Menu) then
        WarningSystem7452em.Menu:Remove()
    end
end)