function WarningSystem7452em:OpenMenu()
    WarningSystem7452em.Menu = vgui.Create("WarningSystem7452em:Menu")
end

--[[
    Desc: Check if warn has expiration
    Return: boolean
]]--

function WarningSystem7452em:HasExpiration(tWarn)
    if( not tWarn.expires_at || tWarn.expires_at == "NULL" ) then
        return false 
    end

    return true
end

--[[
    Desc: Get note of player
    Return: string
]]--

function WarningSystem7452em:GetNote(sSteamID)
    local tUser = self.Users[sSteamID]

    if( not tUser ) then return "" end

    return tUser.note or ""
end

--[[  
    Desc : Get warnings of player
    return : Array
]]

function WarningSystem7452em:GetWarnings(sSteamID)
    local tUser = self.Users[sSteamID]

    if( not tUser ) then return {} end
    if( not tUser.warnings ) then return {} end

    return tUser.warnings 
end

--[[  
    Desc : Get total penalty points of player
    Return : int
]]

function WarningSystem7452em:GetTotalPoints(sSteamID)
    local tWarnings = self:GetWarnings(sSteamID)
    local iPoint = 0

    for k,v in pairs(tWarnings or {}) do
        if( self:HasExpiration(v) ) then
            if( tonumber(v.expires_at) > os.time() ) then
                iPoint = iPoint + v.penalty
            end
        else
            iPoint = iPoint + v.penalty
        end
    end

    return iPoint
end

--[[  
    Desc : Get active warning of player
    Return : int
]]

function WarningSystem7452em:GetActiveWarnings(sSteamID)
    local tWarnings = self:GetWarnings(sSteamID)
    local iActiveWarnings = 0

    for k,v in pairs(tWarnings or {}) do
        if( self:HasExpiration(v) ) then
            if( tonumber(v.expires_at) > os.time() ) then
                iActiveWarnings = iActiveWarnings + 1
            end
        else
            iActiveWarnings = iActiveWarnings + 1
        end
    end

    return iActiveWarnings
end

--[[  
    Desc : Get total warnings of player
    Return : int
]]

function WarningSystem7452em:GetTotalWarnings(sSteamID)
    return table.Count(self:GetWarnings(sSteamID) or {})
end

--[[
    Desc: Wrap strings to not become wider than the given amount of pixels
    Taken from DarkRP
]]

local function charWrap(text, remainingWidth, maxWidth)
    local totalWidth = 0

    text = text:gsub(".", function(char)
        totalWidth = totalWidth + surface.GetTextSize(char)

        -- Wrap around when the max width is reached
        if totalWidth >= remainingWidth then
            -- totalWidth needs to include the character width because it's inserted in a new line
            totalWidth = surface.GetTextSize(char)
            remainingWidth = maxWidth
            return "\n" .. char
        end

        return char
    end)

    return text, totalWidth
end

function WarningSystem7452em:textWrap(text, font, maxWidth)
    local totalWidth = 0

    surface.SetFont(font)

    local spaceWidth = surface.GetTextSize(' ')
    text = text:gsub("(%s?[%S]+)", function(word)
            local char = string.sub(word, 1, 1)
            if char == "\n" or char == "\t" then
                totalWidth = 0
            end

            local wordlen = surface.GetTextSize(word)
            totalWidth = totalWidth + wordlen

            -- Wrap around when the max width is reached
            if wordlen >= maxWidth then -- Split the word if the word is too big
                local splitWord, splitPoint = charWrap(word, maxWidth - (totalWidth - wordlen), maxWidth)
                totalWidth = splitPoint
                return splitWord
            elseif totalWidth < maxWidth then
                return word
            end

            -- Split before the word
            if char == ' ' then
                totalWidth = wordlen - spaceWidth
                return '\n' .. string.sub(word, 2)
            end

            totalWidth = wordlen
            return '\n' .. word
        end)

    return text
end

--[[
    Desc: Splits a text into a table
    Return: table
]]

function WarningSystem7452em:splitText(sText, pnlParent, iOffsetX, iSize, sFont, cColor, bMultiline)
    local tTexts = string.Explode("\n", WarningSystem7452em:textWrap(sText, sFont, iSize))

    local iLines = #tTexts + 1

    local pnlText = vgui.Create("DPanel", pnlParent)
    pnlText:SetSize(iSize, pnlParent:GetTall())
    pnlText:SetPos(iOffsetX, 0)
    if bMultiline then
        function pnlText:Paint(iW, iH)
            for k, v in ipairs(tTexts) do
                draw.SimpleText(v, sFont, iW * 0.5, (iH * 0.5) - ((iLines/2) * iH * 0.3) + k * iH * 0.3, cColor, 1, 1)
            end
        end
    else
        function pnlText:Paint(iW, iH)
            draw.SimpleText(tTexts[1], sFont, iW * 0.5, iH * 0.5, cColor, 1, 1)
        end
    end

    return iSize
end

--[[
    Desc: Shows a notification on the user screen
    Return: void
]]

WarningSystem7452em.NotifList = {}

local iNotifH = 60

local tNotifications = nil

function WarningSystem7452em:Notify(iType, sMessage, iLength)
	if not WarningSystem7452em or not WarningSystem7452em.CFG or not WarningSystem7452em.CFG.theme then return end
	
	tNotifications = tNotifications or {
		[0] = {
			title = WarningSystem7452em:__("notifs.success"),
			color = WarningSystem7452em.CFG.theme.Green
		},
		[1] = {
			title = WarningSystem7452em:__("notifs.error"),
			color = WarningSystem7452em.CFG.theme.Red
		},
		[2] = {
			title = WarningSystem7452em:__("notifs.warning"),
			color = WarningSystem7452em.CFG.theme.Orange
		},
	}

	iLength = tonumber( iLength ) or 10

	surface.SetFont("WarningSystem7452em:25M")
	local w = surface.GetTextSize(sMessage)

	table.insert(self.NotifList, {sTitle = tNotifications[iType].title, sMsg = sMessage, cColor = tNotifications[iType].color, iEnd = CurTime() + iLength, iW = w, x = ScrW(), y = 0, iA = w})

	if not hook.GetTable()["HUDPaint"]["WarningSystem7452em.Notif:HUDPaint"] then
		hook.Add("HUDPaint", "WarningSystem7452em.Notif:HUDPaint", function()
			for k, v in pairs(self.NotifList) do
				v.x = Lerp(RealFrameTime() * 8, v.x, (CurTime() > v.iEnd) and (ScrW() + 1) or (ScrW() - v.iW - 40 - 10))
                v.y = Lerp(RealFrameTime() * 8, v.y, (iNotifH + 10) * (k - 1) + 10)

				if v.x >= ScrW() and CurTime() > v.iEnd then
					table.remove(self.NotifList, k)
					if #self.NotifList == 0 then
						hook.Remove("HUDPaint", "WarningSystem7452em.Notif:HUDPaint")
					end
				end

				surface.SetDrawColor(WarningSystem7452em.CFG.theme.Primary)
				surface.DrawRect(v.x, v.y, v.iW + 40, iNotifH)

				surface.SetDrawColor(v.cColor)
                surface.DrawRect(v.x + 3, v.y + 3, 6, iNotifH - 6)

				draw.SimpleText(v.sTitle, "WarningSystem7452em:30M", v.x + 22, v.y + 19, WarningSystem7452em.CFG.theme.Texts, 0, 1)
				draw.SimpleText(v.sMsg, "WarningSystem7452em:25M", v.x + 22, v.y + 43, WarningSystem7452em.CFG.theme.Texts, 0, 1)
			end
		end)
	end
end

--[[
    Desc: Display warning menu
    Return: void
]]

function WarningSystem7452em:DisplayWarningMenu(sID)
    local pFound = player.GetBySteamID64(sID)
    local sName = sID

    if pFound then sName = pFound:Nick() end 

    local pnlWarning = vgui.Create("EditablePanel")
    pnlWarning:SetSize(ScrH() * 0.35, ScrH() * 0.5)
    pnlWarning:Center()
    pnlWarning:SetAlpha(0)
    pnlWarning:AlphaTo(255, 0.25)
    pnlWarning:MakePopup()
    local iTime = SysTime()
    function pnlWarning:Paint(iW, iH)
        Derma_DrawBackgroundBlur(self, iTime)

        draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Primary)
        draw.RoundedBox(8, 0, iH * 0.1, iW, 1, WarningSystem7452em.CFG.theme.Secondary)

        draw.SimpleText(sName, "WarningSystem7452em:30M", iW * 0.05, iH * 0.05, WarningSystem7452em.CFG.theme.Texts, 0, 1)

        draw.SimpleText(WarningSystem7452em:__("preset"), "WarningSystem7452em:25M", iW * 0.05, iH * 0.13, WarningSystem7452em.CFG.theme.Texts2)
        draw.SimpleText(WarningSystem7452em:__("reason"), "WarningSystem7452em:25M", iW * 0.05, iH * 0.275, WarningSystem7452em.CFG.theme.Texts2)
        draw.SimpleText(WarningSystem7452em:__("penalty"), "WarningSystem7452em:25M", iW * 0.05, iH * 0.59, WarningSystem7452em.CFG.theme.Texts2)
        draw.SimpleText(WarningSystem7452em:__("duration"), "WarningSystem7452em:25M", iW * 0.05, iH * 0.74, WarningSystem7452em.CFG.theme.Texts2)
    end

    local btnClose = vgui.Create("DButton", pnlWarning)
    btnClose:SetSize(pnlWarning:GetTall() * 0.1, pnlWarning:GetTall() * 0.1)
    btnClose:SetPos(pnlWarning:GetWide() - btnClose:GetWide(), 0)
    btnClose:SetText("")
    function btnClose:Paint(iW, iH)
        draw.SimpleText("✕", "WarningSystem7452em:20M", iW * 0.5, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 1, 1)
    end
    function btnClose:DoClick()
        self:GetParent().bClosing = true

        self:GetParent():AlphaTo(0, 0.2, 0, function()
            if not IsValid(self) or not IsValid(self:GetParent()) then return end

            self:GetParent():Remove()
        end)
    end

    function pnlWarning:Think()
        if not self:HasFocus() and not vgui.FocusedHasParent(self) then
            self:MakePopup()
        end
    end

    local pnlPreset = vgui.Create("WarningSystem7452em:DComboBox", pnlWarning)
    pnlPreset:SetSize(pnlWarning:GetWide() * 0.9, pnlWarning:GetTall() * 0.07)
    pnlPreset:SetPos(pnlWarning:GetWide() * 0.05, pnlWarning:GetTall() * 0.18)
    pnlPreset:AddChoice(WarningSystem7452em:__("none"), nil, true)
    for k, v in pairs(WarningSystem7452em.CFG.reasons) do
        pnlPreset:AddChoice(v.reason, k)
    end

    local pnlReason = vgui.Create("WarningSystem7452em:DTextEntry", pnlWarning)
    pnlReason:SetSize(pnlWarning:GetWide() * 0.9, pnlWarning:GetTall() * 0.238)
    pnlReason:SetPos(pnlWarning:GetWide() * 0.05, pnlWarning:GetTall() * 0.325)
    pnlReason:SetMultiline(true)
    pnlReason:SetPlaceholderText(WarningSystem7452em:__("reason") .. "\n\n\n")

    local pnlPenalty = vgui.Create("WarningSystem7452em:DTextEntry", pnlWarning)
    pnlPenalty:SetSize(pnlWarning:GetWide() * 0.9, pnlWarning:GetTall() * 0.07)
    pnlPenalty:SetPos(pnlWarning:GetWide() * 0.05, pnlWarning:GetTall() * 0.64)
    pnlPenalty:SetPlaceholderText("5")

    local pnlDuration = vgui.Create("WarningSystem7452em:DTextEntry", pnlWarning)
    pnlDuration:SetSize(pnlWarning:GetWide() * 0.9, pnlWarning:GetTall() * 0.07)
    pnlDuration:SetPos(pnlWarning:GetWide() * 0.05, pnlWarning:GetTall() * 0.79)
    pnlDuration:SetPlaceholderText("1y 2mo 3d 4h 5m 6s")

    function pnlPreset:OnSelect(iID, sValue, xData)
        if xData == nil then
            pnlReason:SetText("")
            pnlPenalty:SetText("")
            pnlDuration:SetText("")

            return
        end

        local tPreset = WarningSystem7452em.CFG.reasons[xData]

        pnlReason:SetText(tPreset.reason)
        pnlPenalty:SetText(tPreset.penalty)
        pnlDuration:SetText(WarningSystem7452em:FormatTimeToString(tPreset.duration))
    end

    local btnWarn = vgui.Create("WarningSystem7452em:DButton", pnlWarning)
    btnWarn:SetSize(pnlWarning:GetWide() * 0.9, pnlWarning:GetTall() * 0.07)
    btnWarn:SetPos(pnlWarning:GetWide() * 0.05, pnlWarning:GetTall() * 0.90)
    btnWarn:SetText(WarningSystem7452em:__("warn"))
    btnWarn:SetFont("WarningSystem7452em:30M")
    function btnWarn:DoClick()
        local sReason = tostring(pnlReason:GetText()) or ""
        local iPenalty = tonumber(pnlPenalty:GetText()) or 0
        local iDuration = WarningSystem7452em:FormatStringToTime(pnlDuration:GetText() or "")

        WarningSystem7452em:NetStart("WarningSystem7452em:Player:Warn", {
            target = sID,
            reason = sReason,
            penalty = iPenalty,
            duration = iDuration
        })

        if IsValid(WarningSystem7452em.Menu) then
            WarningSystem7452em.Menu:LoadContent("my_warnings", IsValid(pFound) and pFound or sID)
        end

        btnClose:DoClick()
    end
end

--[[
    Desc: Very simple card element
    Return: void
]]

function WarningSystem7452em:DrawCard(sTitle, sContent, xIcon, iX, iY, iW, iH)
    local sFont = "WarningSystem7452em:45M"
    surface.SetFont(sFont)
    local iTotalW = surface.GetTextSize(sContent) + iH * 0.4

    draw.RoundedBox(8, iX, iY, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
    draw.RoundedBox(8, iX + 1, iY + 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)

    draw.SimpleText(sTitle, "WarningSystem7452em:28M", iX + iW * 0.5, iY + iH * 0.3, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
    draw.SimpleText(sContent, sFont, iX + iW * 0.5 - iTotalW * 0.5 + iH * 0.4, iY + iH * 0.7, WarningSystem7452em.CFG.theme.Texts, 0, 1)

    surface.SetMaterial(xIcon)
    surface.SetDrawColor(WarningSystem7452em.CFG.theme.Texts)
    surface.DrawTexturedRect(iX + iW * 0.5 - iTotalW * 0.5, iY + iH * 0.525, iH * 0.3, iH * 0.3)
end

function WarningSystem7452em:InitContextMenu()
    WarningSystem7452em.CMenuOkay = true

    properties.Add("warning_system", {
        MenuLabel = "Warning System",
        Order = 999,
        MenuIcon = "icon16/add.png",

        Action = function() end,

        Filter = function( self, ent, ply )
            return IsValid(ent) and ent:IsPlayer()
        end,

        MenuOpen = function(self, pnlMenuOption, pClicked, tTrace)
            local sID = pClicked:SteamID64()
            local pnlMenu = pnlMenuOption:AddSubMenu()

            if WarningSystem7452em:Can(LocalPlayer(), "add_warn") then
                pnlMenu:AddOption(WarningSystem7452em:__("custom_warning"), function()
                    WarningSystem7452em:DisplayWarningMenu(sID)
                end):SetIcon("icon16/cog.png")

                if WarningSystem7452em.CFG.reasons then
                    local pnlReasonsMenu, pnlReasonsMenuIcon = pnlMenu:AddSubMenu(WarningSystem7452em:__("settings_tabs.preset_reasons"))
                    pnlReasonsMenuIcon:SetIcon("icon16/folder.png")

                    for k, v in pairs(WarningSystem7452em.CFG.reasons) do
                        pnlReasonsMenu:AddOption(v.reason, function()
                            WarningSystem7452em:NetStart("WarningSystem7452em:Player:Warn", {
                                target = sID,
                                reason = v.reason,
                                penalty = v.penalty,
                                duration = v.duration
                            })
                        end):SetIcon("icon16/flag_red.png")
                    end
                end
            end

            if WarningSystem7452em:Can(LocalPlayer(), "view_others_warnings") then
                local pnlStatistics, pnlStatisticsIcon = pnlMenu:AddSubMenu(WarningSystem7452em:__("tabs.statistics"))
                pnlStatisticsIcon:SetIcon("icon16/chart_pie.png")

                WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", {
                    type = "warnings",
                    target = sID
                })

                hook.Add("WarningSystem7452em:Player:InfoReceived", "Warning:Player:" .. pClicked:UserID(), function(sInfo)
                    if( not IsValid(pnlMenu) or not IsValid(pnlStatistics) ) then return end

                    WarningSystem7452em.Users = WarningSystem7452em.Users or {}

                    if( sInfo == "warnings" ) then
                        pnlStatistics:AddOption(WarningSystem7452em:__("penalty_points") .. ": " .. WarningSystem7452em:GetTotalPoints(sID)):SetIcon("icon16/exclamation.png")
                        pnlStatistics:AddOption(WarningSystem7452em:__("active_warnings") .. ": " .. WarningSystem7452em:GetActiveWarnings(sID)):SetIcon("icon16/error.png")
                        pnlStatistics:AddOption(WarningSystem7452em:__("total_warnings") .. ": " .. WarningSystem7452em:GetTotalWarnings(sID)):SetIcon("icon16/error_delete.png")
                    end
                end)

                pnlMenu:AddOption(WarningSystem7452em:__("view_more"), function()
                    if not IsValid(pClicked) then return end
                    if not IsValid(WarningSystem7452em.Menu) then
                        WarningSystem7452em.Menu = vgui.Create("WarningSystem7452em:Menu")
                    end
                    
		    if not IsValid(WarningSystem7452em.Menu) then
			WarningSystem7452em:OpenMenu()					
		    end
							
                    WarningSystem7452em.Menu:LoadContent("my_warnings", pClicked)
                end):SetIcon("icon16/eye.png")
            end
        end,
    })
end
