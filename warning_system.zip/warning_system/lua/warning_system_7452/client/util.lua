surface.CreateFont("WarningSystem7452em:35R", {font = "Poppins Bold", size = ScrH() * 0.035})

surface.CreateFont("WarningSystem7452em:45M", {font = "Poppins Medium", size = ScrH() * 0.045})
surface.CreateFont("WarningSystem7452em:40M", {font = "Poppins Medium", size = ScrH() * 0.04})
surface.CreateFont("WarningSystem7452em:32M", {font = "Poppins Medium", size = ScrH() * 0.032})
surface.CreateFont("WarningSystem7452em:30M", {font = "Poppins Medium", size = ScrH() * 0.03})
surface.CreateFont("WarningSystem7452em:28M", {font = "Poppins Medium", size = ScrH() * 0.028})
surface.CreateFont("WarningSystem7452em:25M", {font = "Poppins Medium", size = ScrH() * 0.025})
surface.CreateFont("WarningSystem7452em:20M", {font = "Poppins Medium", size = ScrH() * 0.02})

WarningSystem7452em.Users = WarningSystem7452em.Users or {}
WarningSystem7452em.PenaltyPoints = WarningSystem7452em.PenaltyPoints or {}
WarningSystem7452em.Stats = WarningSystem7452em.Stats or {}