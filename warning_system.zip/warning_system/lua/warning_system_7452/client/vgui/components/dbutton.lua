local PANEL = {}

AccessorFunc(PANEL, "cBackground", "BackgroundColor")

function PANEL:Init()
    self:SetText("")
    self.sText = "Button"
    self.cBackground = WarningSystem7452em.CFG.theme.Main
    self:SetTextColor(WarningSystem7452em.CFG.theme.Texts)
    self:SetFont("WarningSystem7452em:25M")
    self.iLerp = 0
    self.tBorder = {
        color = color_black,
        width = 0
    }

    function self:SetText(sText) self.sText = sText end
end

function PANEL:GetText() return self.sText end

function PANEL:SetBorder(cColor, iWidth)
    self.tBorder = {
        color = cColor,
        width = iWidth or 1
    }
end

function PANEL:OnMousePressed(iKey)
	if (self.intNextClick && self.intNextClick > CurTime()) then return end

	self.intNextClick = CurTime() + 0.2

    if self.DoClick and iKey == MOUSE_LEFT then
        self:DoClick()
        surface.PlaySound( "buttons/button15.wav" )
    end
end

function PANEL:Paint(iW, iH)
    self.iLerp = Lerp(RealFrameTime() * 8, self.iLerp, self:IsHovered() and 70 or 0)

    draw.RoundedBox(8, 0, 0, iW, iH, self.tBorder.color)
    draw.RoundedBox(8, self.tBorder.width, self.tBorder.width, iW - self.tBorder.width * 2, iH - self.tBorder.width * 2, self:GetBackgroundColor())
    draw.RoundedBox(8, 0, 0, iW, iH, ColorAlpha(color_black, self.iLerp))

    draw.SimpleText(self:GetText(), self:GetFont(), iW * 0.5, iH * 0.5, self:GetTextColor(), 1, 1)
end

vgui.Register("WarningSystem7452em:DButton", PANEL, "DButton")