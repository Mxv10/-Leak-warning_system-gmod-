local PANEL = {}

AccessorFunc(PANEL, "cBackground", "BackgroundColor")

function PANEL:Init()
    self:SetText("")

    self.img = vgui.Create("DImage", self)
    self.img:Dock(FILL)
    self.img:DockMargin(8, 8, 8, 8)  
end

function PANEL:SetImage(sImage)
    local xMat = Material(sImage, "noclamp smooth")

    self.img:SetMaterial(xMat)
    self.img:SetImageColor(WarningSystem7452em.CFG.theme.Texts)
end

vgui.Register("WarningSystem7452em:DImageButton", PANEL, "WarningSystem7452em:DButton")