local PANEL = {}

function PANEL:Init()
    self:SetTextColor(WarningSystem7452em.CFG.theme.Texts)
    self:SetSortItems(false)
    self:SetFont("WarningSystem7452em:20M")
end

function PANEL:Paint(iW, iH)
    draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
    draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)
end

function PANEL:DoClick()
	if self:IsMenuOpen() then
		return self:CloseMenu()
	end

    self:OpenMenu()
    
    for k, v in pairs(self.Menu:GetCanvas():GetChildren()) do
        v:SetTextColor(WarningSystem7452em.CFG.theme.Texts)
        v:SetFont("WarningSystem7452em:20M")
        function v:Paint(w, h)
            surface.SetDrawColor(WarningSystem7452em.CFG.theme.Secondary)
            surface.DrawOutlinedRect(0, -1, w, h + 1)

            if self:IsHovered() then
                surface.SetDrawColor(WarningSystem7452em.CFG.theme.Main)
                surface.DrawRect(1, 1, w - 2, h - 2)
            end
        end
    end

    function self.Menu:Paint(intW, intH)
        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Tertiary)
        surface.DrawRect(0, 0, intW, intH)
        
        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Secondary)
        surface.DrawRect(0, 0, intW, 1)
    end
end

vgui.Register("WarningSystem7452em:DComboBox", PANEL, "DComboBox")