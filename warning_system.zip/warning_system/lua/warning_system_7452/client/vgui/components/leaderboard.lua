local PANEL = {}

function PANEL:Init()
end

function PANEL:Setup(sTitle, cDescs)
    self.sTitle = sTitle
    self.cDescs = cDescs

    self.pnlScroll = vgui.Create("DPanel", self)
    self.pnlScroll:SetSize(self:GetWide() * 0.9, self:GetTall() * 0.78)
    self.pnlScroll:SetPos(self:GetWide() * 0.05, self:GetTall() * 0.17)
    self.pnlScroll.Paint = nil
end

function PANEL:AddRow(sImage, sText, sDesc)
    local xMat = Material("icon16/attach.png")

    local pnlRow = vgui.Create("DPanel", self.pnlScroll)
    pnlRow:Dock(TOP)
    pnlRow:SetTall(self:GetTall() * 0.12)
    pnlRow:DockMargin(0, 0, 0, self:GetTall() * 0.05)
    function pnlRow:Paint(iW, iH)
        surface.SetMaterial(xMat)
        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Texts)
        surface.DrawTexturedRect(0, 0, iH, iH)

        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Primary)
        surface.DrawRect(0, 0, iH, iH)

        draw.SimpleText(sText, "WarningSystem7452em:20M", iH * 1.3, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)
        draw.SimpleText(sDesc, "WarningSystem7452em:30M", iW * 0.98, iH * 0.5, self:GetParent():GetParent().cDescs, 2, 1)
    end

    local pnlAvatar = vgui.Create("HTML", pnlRow)
    pnlAvatar:SetSize(pnlRow:GetTall(), pnlRow:GetTall())
    pnlAvatar:SetHTML(
        [[
            <style type="text/css">
                body{
                    padding: 0;
                    margin: 0;
                    background-image: url("]] .. sImage .. [[");
                    background-size: cover;
                }
            </style>
        ]]
    )
end

function PANEL:Paint(iW, iH)
    draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
    draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)
    
    draw.SimpleText(self.sTitle, "WarningSystem7452em:25M", iW * 0.05, iH * 0.03, WarningSystem7452em.CFG.theme.Texts2)
end

vgui.Register("WarningSystem7452em:Leaderboard", PANEL, "DPanel")