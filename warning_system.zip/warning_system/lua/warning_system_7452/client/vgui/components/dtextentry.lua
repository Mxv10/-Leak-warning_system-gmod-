local PANEL = {}

function PANEL:Init()
    self.txt = vgui.Create("DTextEntry", self)
    self.txt:SetDrawLanguageID(false)
    self.txt:SetTextColor(WarningSystem7452em.CFG.theme.Texts)
    self.txt:Dock(FILL)
    self.txt:SetFont("WarningSystem7452em:25M")
    self.txt:DockMargin(8, 8, 8, 8)
    self.txt:SetPlaceholderText("")
    function self.txt:Paint(iW, iH)
        if self:GetText() == "" and self:GetPlaceholderText() ~= "" then
            draw.SimpleText(self:GetPlaceholderText(), self:GetFont(), 3, iH * 0.5, WarningSystem7452em.CFG.theme.Texts2, 0, 1)
        end
        self:DrawTextEntryText(self:GetTextColor(), Color(86, 40, 238), self:GetTextColor())
    end
    function self.txt:OnEnter()
        self:GetParent():OnEnter()
    end
    function self.txt:OnChange()
        if( self:GetParent().OnChange ) then
            self:GetParent():OnChange()
        end
    end
end

function PANEL:GetText() return self.txt:GetText() end
function PANEL:OnEnter() end
function PANEL:SetText(...) return self.txt:SetText(...) end
function PANEL:SetFont(...) return self.txt:SetFont(...) end
function PANEL:SetMultiline(...) return self.txt:SetMultiline(...) end
function PANEL:SetPlaceholderText(...) return self.txt:SetPlaceholderText(...) end

function PANEL:Paint(iW, iH)
    draw.RoundedBox(8, 0, 0, iW, iH, self.txt:HasFocus() and WarningSystem7452em.CFG.theme.Main or WarningSystem7452em.CFG.theme.Secondary)
    draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)
end

vgui.Register("WarningSystem7452em:DTextEntry", PANEL, "DPanel")