local PANEL = {}

local ScrH = ScrH

function PANEL:Init()
    self:SetSize(ScrH() * 0.95, ScrH() * 0.625)
    self:Center()
    self:MakePopup()
    self.startTime = SysTime()
    self:SetAlpha(0)
    self:AlphaTo(255, 0.25)

    self.pnlSidebar = vgui.Create("DPanel", self)
    self.pnlSidebar:Dock(LEFT)
    self.pnlSidebar:SetWide(self:GetWide() * 0.275)
    function self.pnlSidebar:Paint(iW, iH)
        draw.RoundedBoxEx(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary, true, false, true, false)

        draw.SimpleText("  arning    ystem", "WarningSystem7452em:40M", iW * 0.5, iH * 0.049, WarningSystem7452em.CFG.theme.Texts, 1, 1)
        draw.SimpleText("W", "WarningSystem7452em:40M", iW * 0.162, iH * 0.049, WarningSystem7452em.CFG.theme.Main, 1, 1)
        draw.SimpleText("S", "WarningSystem7452em:40M", iW * 0.546, iH * 0.049, WarningSystem7452em.CFG.theme.Main, 1, 1)
    end

    self.pnlSidebar.pnlScroll = vgui.Create("DScrollPanel", self.pnlSidebar)
    self.pnlSidebar.pnlScroll:Dock(FILL)
    self.pnlSidebar.pnlScroll:DockMargin(self:GetWide() * 0.01, self:GetTall() * 0.1, self:GetWide() * 0.01, self:GetTall() * 0.03)

    self.pnlActive = nil
    self.sActive = nil

    for k, v in SortedPairsByMemberValue(WarningSystem7452em.Categories or {}, "Order") do
        if not v:isAllowed(LocalPlayer()) then continue end

        local xIcon = v.icon

        local btn = vgui.Create("DButton", self.pnlSidebar.pnlScroll)
        btn:Dock(TOP)
        btn:SetText("")
        btn:SetTall(self:GetTall() * 0.075)
        btn:DockMargin(0, 0, 0, self:GetTall() * 0.01)
        btn.iLerp = 0
        btn.sText = v.title
        btn.Paint = function(pnl, iW, iH)
            pnl.iLerp = Lerp(RealFrameTime() * 15, pnl.iLerp, self.pnlActive == pnl and 255 or 0)
            draw.RoundedBox(8, 0, 0, iW, iH, ColorAlpha(WarningSystem7452em.CFG.theme.Tertiary, pnl.iLerp))

            if self.pnlActive == pnl then
                draw.SimpleText(pnl.sText, "WarningSystem7452em:32M", iH * 1, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)
                
                surface.SetDrawColor(WarningSystem7452em.CFG.theme.Texts)
            else
                draw.SimpleText(pnl.sText, "WarningSystem7452em:32M", iH * 1, iH * 0.5, WarningSystem7452em.CFG.theme.Texts2, 0, 1)
                
                surface.SetDrawColor(WarningSystem7452em.CFG.theme.Texts2)
            end
            
            surface.SetMaterial(xIcon)
            surface.DrawTexturedRect(iH * 0.2, iH * 0.2, iH * 0.6, iH * 0.6)

        end
        btn.DoClick = function()
            self:LoadContent(k)
        end
    end

    self.pnlTitle = vgui.Create("DPanel", self)
    self.pnlTitle:Dock(TOP)
    self.pnlTitle:SetTall(self:GetTall() * 0.09)
    function self.pnlTitle:Paint(iW, iH)
        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Secondary)
        surface.DrawRect(0, iH - 2, iW, 2)
    
        draw.SimpleText(self:GetParent().sActive or "", "WarningSystem7452em:32M", iW * 0.025, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)
    end

    self.pnlTitle.btnClose = vgui.Create("DButton", self.pnlTitle)
    self.pnlTitle.btnClose:Dock(RIGHT)
    self.pnlTitle.btnClose:SetText("")
    function self.pnlTitle.btnClose:Paint(iW, iH)
        draw.SimpleText("✕", "WarningSystem7452em:20M", iW * 0.5, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 1, 1)
    end
    self.pnlTitle.btnClose.DoClick = function()
        self:Delete()
    end

    self.pnlContent = vgui.Create("DPanel", self)
    self.pnlContent:Dock(FILL)
    self.pnlContent:DockMargin(self:GetTall() * 0.02, self:GetTall() * 0.02, self:GetTall() * 0.02, self:GetTall() * 0.02)
    self.pnlContent.Paint = nil

    self.pnlLoader = vgui.Create("DPanel", self)
    self.pnlLoader:SetSize(self:GetWide() - self.pnlSidebar:GetWide(), self:GetTall() - self.pnlTitle:GetTall())
    self.pnlLoader:SetPos(self.pnlSidebar:GetWide(), self.pnlTitle:GetTall())
    self.pnlLoader:SetVisible(false)
    self.pnlLoader.xMat = Material("materials/warning_system/cog.png", "noclamp smooth")
    self.pnlLoader.iSize = 0
    self.pnlLoader.iAlpha = 255
    function self.pnlLoader:Paint(iW, iH)
        draw.RoundedBoxEx(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Primary, false, false, false, true)

        for i = 0, 2 do
            draw.RoundedBox(4, iW * 0.5 - i * 16 + 12, iH * 0.5 + 4 - 8 - math.Clamp(math.sin((CurTime() - 0.3 * i) * 4), 0, 1) * 20, 8, 8, WarningSystem7452em.CFG.theme.Texts)
        end
    end

    timer.Simple(0.1, function()
        if WarningSystem7452em.tLastLoaded then
            self:LoadContent(unpack(WarningSystem7452em.tLastLoaded))
        else
            self:LoadContent("my_warnings")
        end
    end)
end

function PANEL:LoadContent(sPanel, ...)
    if not IsValid(self.pnlContent) then return end
    
    WarningSystem7452em.tLastLoaded = {sPanel, unpack({...} or {})}

    local tContent = WarningSystem7452em.Categories[sPanel]

    if not tContent then return end

    self.sActive = tContent.title

    for k, v in ipairs(self.pnlSidebar.pnlScroll:GetChild(0):GetChildren()) do
        if v.sText == tContent.title then
            self.pnlActive = v
            break 
        end
    end 

    local xArgs = {...}

    -- begins animation
    self.pnlContent:SetAlpha(255)
    self.pnlContent:AlphaTo(0, 0.1, 0, function()
        if IsValid(self) then
            self.pnlContent:Clear()
            self.pnlContent.Paint = nil

            if tContent.onLoad then
                -- shows loader and start loading content
                self.pnlLoader:SetVisible(true)
                self.tNextCall = {
                    fCall = tContent.onOpen,
                    xArgs = xArgs
                }
                tContent:onLoad(unpack(xArgs))
            else
                -- shows content without loading
                tContent:onOpen(self.pnlContent, unpack(xArgs))
                
                self.pnlContent:SetAlpha(0)
                self.pnlContent:AlphaTo(255, 0.1)
            end
        end
    end)
end

function PANEL:StopLoading()
    if self.tNextCall then
        -- display content with loaded data (still invisible here)
        self.tNextCall:fCall(self.pnlContent, unpack(self.tNextCall.xArgs))
        self.tNextCall = nil
    end

    -- hide loader and display content
    self.pnlLoader:SetVisible(false)
    self.pnlContent:SetAlpha(0)
    self.pnlContent:AlphaTo(255, 0.25)
end

function PANEL:Delete()
    self:AlphaTo(0, .25, 0, function()
        if IsValid(self) then
            self:Remove()
        end
    end)
end

function PANEL:Paint(iW, iH)
    draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Primary)
end

vgui.Register("WarningSystem7452em:Menu", PANEL, "EditablePanel")