local CATEGORY = {}

CATEGORY.Order = 2
CATEGORY.title = WarningSystem7452em:__("tabs.online_players")
CATEGORY.icon = Material("materials/warning_system/user.png", "noclamp smooth")

function CATEGORY:isAllowed(pPlayer)
    self.title = WarningSystem7452em:__("tabs.online_players")

    return WarningSystem7452em:Can(pPlayer, "view_others_warnings")
end

function CATEGORY:onLoad()
    WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", {
        type = "fetch_penalty_points",
        target = "NULL"
    })
end

function CATEGORY:onOpen(pnlContent, ...)
    local tPlayers = player.GetAll()
    local iPlayers = 0
    
    local iFiltered = 0

    local sPlayersCount = nil 
    local iPlayerCountsWide = nil

    function pnlContent:Paint(iW, iH)
        draw.SimpleText(sPlayersCount, "WarningSystem7452em:30M", 0, iH * 0.035, WarningSystem7452em.CFG.theme.Texts, 0, 1)
        draw.SimpleText(WarningSystem7452em:__("x_displayed"):format(iFiltered), "WarningSystem7452em:25M", iPlayerCountsWide + iW * 0.01, iH * 0.0375, WarningSystem7452em.CFG.theme.Texts2, 0, 1)
    end

    local pnlScroll = vgui.Create("WarningSystem7452em:DScrollPanel", pnlContent)
    pnlScroll:SetSize(pnlContent:GetWide() + 10, pnlContent:GetTall() * 0.91)
    pnlScroll:SetPos(0, pnlContent:GetTall() - pnlScroll:GetTall())

    local pnlList = vgui.Create("DIconLayout", pnlScroll)
    pnlList:SetSize(pnlScroll:GetWide() - 10, pnlScroll:GetTall())
    pnlList:SetSpaceX(pnlList:GetWide() * 0.02)
    pnlList:SetSpaceY(pnlList:GetWide() * 0.02)

    for k, v in ipairs(tPlayers) do
        iPlayers = iPlayers + 1

        local pnlPlayer = pnlList:Add("DPanel")
        pnlPlayer:SetSize(pnlList:GetWide() * 0.49, pnlContent:GetTall() * 0.1)
        pnlPlayer.tSearch = {
            v:Nick(),
            v:GetUserGroup(),
            v:SteamID(),
            v:SteamID64(),
        }
		
	if DarkRP then table.insert(pnlPlayer.tSearch, v:getDarkRPVar("job")) end

        surface.SetFont("WarningSystem7452em:30M")
        local iWide = surface.GetTextSize(v:Nick() .. " - ")

        function pnlPlayer:Paint(iW, iH)
            if not IsValid(v) then
                self:Remove()
                return
            end

            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)

            local sID = v:SteamID64()

            if( v:IsBot() or sID == nil ) then
                sID = "BOT"
            end

            draw.SimpleText(v:Nick() .. " - ", "WarningSystem7452em:30M", iW * 0.15, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)
            draw.SimpleText(WarningSystem7452em.PenaltyPoints[sID .. "_"] or 0, "WarningSystem7452em:30M", iW * 0.1525 + iWide, iH * 0.5, WarningSystem7452em.CFG.theme.Red, 0, 1)
        end

        local pnlIcon = vgui.Create("AvatarImage", pnlPlayer)
        pnlIcon:SetSize(pnlPlayer:GetTall() * 0.6, pnlPlayer:GetTall() * 0.6)
        pnlIcon:SetPos(pnlPlayer:GetTall() * 0.2, pnlPlayer:GetTall() * 0.2)
        pnlIcon:SetPlayer(v, pnlIcon:GetTall())

        local btnGo = vgui.Create("DButton", pnlPlayer)
        btnGo:Dock(FILL)
        btnGo:SetText("")
        btnGo.Paint = nil
        function btnGo:DoClick()
            if IsValid(WarningSystem7452em.Menu) then
                WarningSystem7452em.Menu:LoadContent("my_warnings", v)
            end
        end
    end

    iFiltered = iPlayers

    sPlayersCount = WarningSystem7452em:__("x_online_players"):format(iPlayers)
    surface.SetFont("WarningSystem7452em:30M")
    iPlayerCountsWide = surface.GetTextSize(sPlayersCount)
    
    local txtSearch = vgui.Create("WarningSystem7452em:DTextEntry", pnlContent)
    txtSearch:SetSize(pnlContent:GetWide() * 0.3, pnlContent:GetTall() * 0.07)
    txtSearch:SetPos(pnlContent:GetWide() - txtSearch:GetWide(), 0)
    txtSearch:SetPlaceholderText(WarningSystem7452em:__("search_player"))
    function txtSearch.txt:OnChange()
        iFiltered = 0
        for _, pnl in pairs(pnlList:GetChildren()) do
			local bShow = false
			for _, sVal in pairs(pnl.tSearch) do
                if (sVal:lower()):find(self:GetText():lower(), 1, true) then
                    bShow = true
                    break
                end
			end
			pnl:SetVisible(bShow)
            if bShow then iFiltered = iFiltered + 1 end
		end
		pnlList:Layout()
    end
end

WarningSystem7452em:AddCategory("online_players", CATEGORY)
