local CATEGORY = {}

CATEGORY.Order = 1
CATEGORY.title = WarningSystem7452em:__("tabs.my_warnings")
CATEGORY.icon = Material("materials/warning_system/warning.png", "noclamp smooth")

function CATEGORY:isAllowed(pPlayer)
    self.title = WarningSystem7452em:__("tabs.my_warnings")

    return true
end

function CATEGORY:onLoad(...)
    local tArgs = {...}

    local pUser = isstring(tArgs[1]) and tArgs[1] or IsValid(tArgs[1]) and tArgs[1] or LocalPlayer()

    local sID = nil
    if isstring(pUser) then
        sID = pUser
    else
        sID = pUser:SteamID64()
    end
    
    WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", {
        types = {"warnings", "note"},
        target = sID
    })
end

function CATEGORY:onOpen(pnlContent, ...)
    local tArgs = {...}

    local pUser = isstring(tArgs[1]) and tArgs[1] or IsValid(tArgs[1]) and tArgs[1] or LocalPlayer()

    local sID = nil
    local sName = nil
    if isstring(pUser) then
        sID = pUser
    else
        sID = pUser:SteamID64()
        sName = pUser:Nick()
    end

    local pnlScroll = vgui.Create("WarningSystem7452em:DScrollPanel", pnlContent)
    
    function pnlContent:Paint(iW, iH)
        draw.SimpleText(sName or sID, "WarningSystem7452em:40M", iW * 0.5, iH * 0.022, WarningSystem7452em.CFG.theme.Texts, 1, 1)
        draw.SimpleText(WarningSystem7452em:GetTotalPoints(sID) .. " " .. WarningSystem7452em:__("penalty_points"):lower(), "WarningSystem7452em:30M", (iW / 3) - (iW / 6), iH * 0.0825, WarningSystem7452em.CFG.theme.Red, 1, 1)
        draw.SimpleText(WarningSystem7452em:GetActiveWarnings(sID) .. " " .. WarningSystem7452em:__("active_warnings"):lower(), "WarningSystem7452em:30M", (iW / 3) * 2 - (iW / 6), iH * 0.0825, WarningSystem7452em.CFG.theme.Orange, 1, 1)
        draw.SimpleText(WarningSystem7452em:GetTotalWarnings(sID) .. " " .. WarningSystem7452em:__("total_warnings"):lower(), "WarningSystem7452em:30M", (iW / 3) * 3 - (iW / 6), iH * 0.0825, WarningSystem7452em.CFG.theme.Green, 1, 1)

        draw.SimpleText(WarningSystem7452em:__("by"), "WarningSystem7452em:30M", iW * 0.09, select(2, pnlScroll:GetPos()) - iH * 0.035, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
        draw.SimpleText(WarningSystem7452em:__("reason"), "WarningSystem7452em:30M", iW * 0.32, select(2, pnlScroll:GetPos()) - iH * 0.035, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
        draw.SimpleText(WarningSystem7452em:__("penalty"), "WarningSystem7452em:30M", iW * 0.535, select(2, pnlScroll:GetPos()) - iH * 0.035, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
        draw.SimpleText(WarningSystem7452em:__("date"), "WarningSystem7452em:30M", iW * 0.7, select(2, pnlScroll:GetPos()) - iH * 0.035, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
        draw.SimpleText(WarningSystem7452em:__("expiration"), "WarningSystem7452em:30M", iW * 0.89, select(2, pnlScroll:GetPos()) - iH * 0.035, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
    end


    if WarningSystem7452em:Can(LocalPlayer(), "view_note") then
        local txtNote = vgui.Create("WarningSystem7452em:DTextEntry", pnlContent)
        txtNote:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.17)
        txtNote:SetPos(0, pnlContent:GetTall() * 0.14)
        txtNote:SetMultiline(true)
        txtNote:SetText(WarningSystem7452em:GetNote(sID))
        txtNote.txt:SetEditable(WarningSystem7452em:Can(LocalPlayer(), "edit_note"))
        function txtNote.txt:OnGetFocus()
            self.sBefore = self:GetText()
        end
        function txtNote.txt:OnLoseFocus()
            if self.sBefore == self:GetText() then return end

            self.sBefore = self:GetText()

            WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateNote", {
                target = sID,
                note = self:GetText()
            })
        end

        pnlScroll:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.6)
        pnlScroll:SetPos(0, pnlContent:GetTall() * 0.4)
    else
        pnlScroll:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.8)
        pnlScroll:SetPos(0, pnlContent:GetTall() * 0.2)
    end

    local tWarns = WarningSystem7452em:GetWarnings(sID)

    for i = #tWarns, 1, -1 do
        local tWarn = tWarns[i]
        local pnlWarning = vgui.Create("DPanel", pnlScroll)
        pnlWarning:Dock(TOP)
        pnlWarning:SetTall(pnlContent:GetTall() * 0.1)
        pnlWarning:DockMargin(0, 0, 0, pnlWarning:GetTall() * 0.1)
        pnlWarning.expired = (tWarn.expires_at and tWarn.expires_at != "NULL") and tonumber(tWarn.expires_at) < os.time()
        function pnlWarning:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, self.expired and ColorAlpha(WarningSystem7452em.CFG.theme.Tertiary, 80) or WarningSystem7452em.CFG.theme.Tertiary)
        end

        pnlWarning:InvalidateParent(true)

        local iOffsetX = 0

        local cMain = pnlWarning.expired and WarningSystem7452em.CFG.theme.Texts2 or WarningSystem7452em.CFG.theme.Texts

        iOffsetX = iOffsetX + WarningSystem7452em:splitText(tWarn.administrator, pnlWarning, iOffsetX, pnlScroll:GetWide() * 0.09 * 2, "WarningSystem7452em:20M", cMain, true)
        iOffsetX = iOffsetX + WarningSystem7452em:splitText(tWarn.reason, pnlWarning, iOffsetX, pnlScroll:GetWide() * 0.14 * 2, "WarningSystem7452em:20M", cMain, true)
        iOffsetX = iOffsetX + WarningSystem7452em:splitText(tostring(tWarn.penalty), pnlWarning, iOffsetX, pnlScroll:GetWide() * 0.076 * 2, "WarningSystem7452em:30M", cMain, true)
        iOffsetX = iOffsetX + WarningSystem7452em:splitText(os.date(WarningSystem7452em.CFG.TimeFormat, tonumber(tWarn.created_at)), pnlWarning, iOffsetX, pnlScroll:GetWide() * 0.092 * 2, "WarningSystem7452em:20M", cMain, true)
        iOffsetX = iOffsetX + WarningSystem7452em:splitText((tWarn.expires_at and tWarn.expires_at != "NULL" ) and os.date("%d/%m/%Y %H:%M", tWarn.expires_at) or "Never", pnlWarning, iOffsetX, pnlScroll:GetWide() * 0.092 * 2, "WarningSystem7452em:20M", pnlWarning.expired and WarningSystem7452em.CFG.theme.Texts2 or WarningSystem7452em.CFG.theme.Green, true)
    
        if WarningSystem7452em:Can(LocalPlayer(), "remove_warn") then
            local pnlOver = vgui.Create("DPanel", pnlWarning)
            pnlOver:Dock(FILL)
            pnlOver.iLerp = 0
            function pnlOver:Paint(iW ,iH)
                self.iLerp = Lerp(RealFrameTime() * 10, self.iLerp, self.bDisplay and 100 or 0)

                draw.RoundedBox(8, 0, 0, iW, iH, ColorAlpha(WarningSystem7452em.CFG.theme.Red, self.iLerp))
            end

            timer.Simple(0.1, function()
                if not IsValid(pnlOver) then return end
                    
                local btnRemove = vgui.Create("WarningSystem7452em:DImageButton", pnlWarning)
                btnRemove:SetVisible(false)
                btnRemove:SetImage("materials/warning_system/cross.png")
                btnRemove:SetBackgroundColor(WarningSystem7452em.CFG.theme.Red)
                if IsValid(btnRemove) and IsValid(pnlWarning) then
                    btnRemove:SetSize(pnlWarning:GetTall(), pnlWarning:GetTall())
                    btnRemove:SetPos(pnlWarning:GetWide(), 0)

                    local iDock = pnlWarning:GetTall() * 0.35
                    btnRemove.img:DockMargin(iDock, iDock, iDock, iDock)

                    btnRemove:SetVisible(true)
                end

                local function onOpen()
                    btnRemove:MoveTo(pnlWarning:GetWide() - btnRemove:GetWide(), 0, 0.1)
                    pnlOver.bDisplay = true
                end
                local function onClose()
                    btnRemove:MoveTo(pnlWarning:GetWide(), 0, 0.1)
                    pnlOver.bDisplay = nil
                end

                pnlOver.OnCursorEntered = onOpen
                pnlOver.OnCursorExited = function()
                    if not btnRemove:IsHovered() then onClose() end
                end
                btnRemove.OnCursorExited = function()
                    if not pnlOver:IsHovered() then onClose() end
                end
                btnRemove.DoClick = function()
                    WarningSystem7452em:NetStart("WarningSystem7452em:Player:UnWarn", { id = tWarn.id, target = sID })
                    pnlWarning:Remove()
                end
            end)
        end
    end

    if WarningSystem7452em:Can(LocalPlayer(), "add_warn") then
        pnlScroll:SetTall(pnlScroll:GetTall() - pnlContent:GetTall() * 0.09)
        
        local btnWarn = vgui.Create("WarningSystem7452em:DButton", pnlContent)
        btnWarn:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.07)
        btnWarn:SetPos(0, pnlContent:GetTall() - btnWarn:GetTall())
        btnWarn:SetText(WarningSystem7452em:__("warn_this_player"))
        btnWarn:SetFont("WarningSystem7452em:30M")
        function btnWarn:DoClick()
            WarningSystem7452em:DisplayWarningMenu(sID)
        end
    end
end

WarningSystem7452em:AddCategory("my_warnings", CATEGORY)
