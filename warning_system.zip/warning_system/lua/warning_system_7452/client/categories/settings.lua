local CATEGORY = {}

CATEGORY.Order = 4
CATEGORY.title = WarningSystem7452em:__("tabs.settings")
CATEGORY.icon = Material("materials/warning_system/cog.png", "noclamp smooth")

local tOtherBlacklist = {
    ["reasons"] = true,
    ["theme"] = true,
    ["thresholds"] = true,
    ["permissions"] = true,
}

function CATEGORY:isAllowed(pPlayer)
    self.title = WarningSystem7452em:__("tabs.settings")

    return WarningSystem7452em:Can(pPlayer, "view_settings")
end

function CATEGORY:onLoad()
    WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", {
        type = "settings",
        target = "null"
    })
end

-- Preset Reasons
function CATEGORY:ShowPresetReasons(pnlTabContent)
    function pnlTabContent:Paint(iW, iH)
        draw.SimpleText(WarningSystem7452em:__("reason") .. " *", "WarningSystem7452em:25M", 0, iH * 0.77, WarningSystem7452em.CFG.theme.Texts2)
        draw.SimpleText(WarningSystem7452em:__("penalty") .. " *", "WarningSystem7452em:25M", iW * 0.61, iH * 0.77, WarningSystem7452em.CFG.theme.Texts2)
        draw.SimpleText(WarningSystem7452em:__("duration"), "WarningSystem7452em:25M", iW * 0.77, iH * 0.77, WarningSystem7452em.CFG.theme.Texts2)
        
        draw.RoundedBox(8, 0, 0, iW, iH * 0.75, WarningSystem7452em.CFG.theme.Secondary)
        draw.RoundedBox(8, 1, 1, iW - 2, iH * 0.75 - 2, WarningSystem7452em.CFG.theme.Tertiary)
    end

    local iMargin = pnlTabContent:GetWide() * 0.01

    local pnlReasonsList = vgui.Create("WarningSystem7452em:DScrollPanel", pnlTabContent)
    pnlReasonsList:SetSize(pnlTabContent:GetWide() - iMargin * 2, pnlTabContent:GetTall() * 0.75 - pnlTabContent:GetWide() * 0.01 * 2)
    pnlReasonsList:SetPos(iMargin, iMargin)

    local iMargin = pnlTabContent:GetTall() * 0.02

    for k,v in pairs(WarningSystem7452em.CFG.reasons or {}) do
        local pnlReason = vgui.Create("DPanel", pnlReasonsList)
        pnlReason:Dock(TOP)
        pnlReason:SetTall(pnlTabContent:GetTall() * 0.075)
        pnlReason:DockMargin(0, 0, 0, iMargin)
        function pnlReason:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Primary)
        end

        surface.SetFont("WarningSystem7452em:25M")
        local sText = "\"" .. v.reason .. "\""
        local iWide = math.Clamp(surface.GetTextSize(sText), 0, pnlTabContent:GetWide() * 0.5)

        local lblReason = Label(sText, pnlReason)
        lblReason:SetSize(iWide, pnlReason:GetTall())
        lblReason:SetFont("WarningSystem7452em:25M")
        lblReason:SetPos(pnlReasonsList:GetWide() * 0.01)
        lblReason:SetTextColor(WarningSystem7452em.CFG.theme.Texts)

        local lblReason = Label(WarningSystem7452em:__("penalty") .. ": " .. v.penalty .. " - " .. WarningSystem7452em:__("duration") .. ": " .. WarningSystem7452em:FormatTimeToString(v.duration), pnlReason)
        lblReason:SetSize(pnlReasonsList:GetWide() * 0.5, pnlReason:GetTall())
        lblReason:SetFont("WarningSystem7452em:25M")
        lblReason:SetPos(pnlReasonsList:GetWide() * 0.02 + iWide)
        lblReason:SetTextColor(WarningSystem7452em.CFG.theme.Texts2)

        local btnRemove = vgui.Create("WarningSystem7452em:DImageButton", pnlReason)
        btnRemove:SetSize(pnlReason:GetTall() - 2, pnlReason:GetTall() - 2)
        btnRemove:Dock(RIGHT)
        btnRemove:SetImage("materials/warning_system/cross.png")
        local iMargin = pnlReason:GetTall() * 0.3
        btnRemove.img:DockMargin(iMargin, iMargin, iMargin, iMargin)
        timer.Simple(0, function()
            btnRemove:SetVisible(true)
            btnRemove:SetPos(pnlReason:GetWide() - btnRemove:GetWide() - 1, 1)
        end)
        function btnRemove:DoClick()
            WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
                key = "reasons",
                removeId = k
            })

            pnlReason:Remove()
        end
    end
    local txtReason = vgui.Create("WarningSystem7452em:DTextEntry", pnlTabContent)
    txtReason:SetPos(0, pnlTabContent:GetTall() * 0.83)
    txtReason:SetSize(pnlTabContent:GetWide() * 0.6, pnlTabContent:GetTall() * 0.07)
    txtReason:SetPlaceholderText("Lorem ipsum dolor sit amet")

    local txtPenalty = vgui.Create("WarningSystem7452em:DTextEntry", pnlTabContent)
    txtPenalty:SetPos(pnlTabContent:GetWide() * 0.61, pnlTabContent:GetTall() * 0.83)
    txtPenalty:SetSize(pnlTabContent:GetWide() * 0.15, pnlTabContent:GetTall() * 0.07)
    txtPenalty:SetPlaceholderText("8")
    txtPenalty.txt:SetNumeric(true)

    local txtDuration = vgui.Create("WarningSystem7452em:DTextEntry", pnlTabContent)
    txtDuration:SetPos(pnlTabContent:GetWide() * 0.77, pnlTabContent:GetTall() * 0.83)
    txtDuration:SetSize(pnlTabContent:GetWide() * 0.23, pnlTabContent:GetTall() * 0.07)
    txtDuration:SetPlaceholderText("1y 1mo 1h 1m 1s")

    local btnAdd = vgui.Create("WarningSystem7452em:DButton", pnlTabContent)
    btnAdd:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    btnAdd:SetPos(0, pnlTabContent:GetTall() - btnAdd:GetTall())
    btnAdd:SetText(WarningSystem7452em:__("settings_tabs.add_this_reason"))
    btnAdd:SetFont("WarningSystem7452em:30M")
    function btnAdd:DoClick()
        if txtReason:GetText() == "" then return end

        local iPenalty = tonumber(txtPenalty:GetText() or "") or 1

        WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
            key = "reasons",
            value = {
                reason = txtReason:GetText(),
                penalty = iPenalty,
                duration = WarningSystem7452em:FormatStringToTime(txtDuration:GetText())
            }
        })

        WarningSystem7452em.Menu:LoadContent("settings", "preset_reasons")
    end
end

// Thresholds
-- Preset Reasons
function CATEGORY:ShowThresholds(pnlTabContent)
    function pnlTabContent:Paint(iW, iH)
        draw.RoundedBox(8, 0, 0, iW, iH * 0.4725, WarningSystem7452em.CFG.theme.Secondary)
        draw.RoundedBox(8, 1, 1, iW - 2, iH * 0.4725 - 2, WarningSystem7452em.CFG.theme.Tertiary)
    end

    local iMargin = pnlTabContent:GetWide() * 0.01

    local pnlReasonsList = vgui.Create("WarningSystem7452em:DScrollPanel", pnlTabContent)
    pnlReasonsList:SetSize(pnlTabContent:GetWide() - iMargin * 2, pnlTabContent:GetTall() * 0.4725 - pnlTabContent:GetWide() * 0.01 * 2)
    pnlReasonsList:SetPos(iMargin, iMargin)

    local iMargin = pnlTabContent:GetTall() * 0.02

    for k,v in pairs(WarningSystem7452em.CFG.thresholds or {}) do
        local pnlReason = vgui.Create("DPanel", pnlReasonsList)
        pnlReason:Dock(TOP)
        pnlReason:SetTall(pnlTabContent:GetTall() * 0.075)
        pnlReason:DockMargin(0, 0, 0, iMargin)
        function pnlReason:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Primary)
        end

        surface.SetFont("WarningSystem7452em:25M")
        local sText = v.penalty .. " " .. WarningSystem7452em:__("penalty_points"):lower()
        local iWide = math.Clamp(surface.GetTextSize(sText), 0, pnlTabContent:GetWide() * 0.5)

        local lblReason = Label(sText, pnlReason)
        lblReason:SetSize(iWide, pnlReason:GetTall())
        lblReason:SetFont("WarningSystem7452em:25M")
        lblReason:SetPos(pnlReasonsList:GetWide() * 0.01)
        lblReason:SetTextColor(WarningSystem7452em.CFG.theme.Texts)

        local tParams = WarningSystem7452em.Thresholds[v.name].Params

        local sDetails = "Type: " .. v.name:gsub("^%l", string.upper)

        for i, j in ipairs(tParams) do
            -- v.params[i], j.name, j.type

            if j.type == "time" then
                sDetails = sDetails .. " - " .. WarningSystem7452em:FormatTimeToString(v.params[i]) 
            elseif j.name ~= "reason" then
                sDetails = sDetails .. " - " .. v.params[i] 
            end
        end

        local lblReason = Label(sDetails, pnlReason)
        lblReason:SetSize(pnlReasonsList:GetWide() * 0.5, pnlReason:GetTall())
        lblReason:SetFont("WarningSystem7452em:25M")
        lblReason:SetPos(pnlReasonsList:GetWide() * 0.02 + iWide)
        lblReason:SetTextColor(WarningSystem7452em.CFG.theme.Texts2)

        local btnRemove = vgui.Create("WarningSystem7452em:DImageButton", pnlReason)
        btnRemove:SetSize(pnlReason:GetTall() - 2, pnlReason:GetTall() - 2)
        btnRemove:Dock(RIGHT)
        btnRemove:SetImage("materials/warning_system/cross.png")
        local iMargin = pnlReason:GetTall() * 0.3
        btnRemove.img:DockMargin(iMargin, iMargin, iMargin, iMargin)
        timer.Simple(0, function()
            btnRemove:SetVisible(true)
            btnRemove:SetPos(pnlReason:GetWide() - btnRemove:GetWide() - 1, 1)
        end)
        function btnRemove:DoClick()
            WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
                key = "threshold",
                removeId = k
            })

            pnlReason:Remove()
        end
    end

    local tThreshold = {
        name = "",
        penalty = 0,
        params = {}
    }

    local txtThreshold = vgui.Create("WarningSystem7452em:DTextEntry", pnlTabContent)
    txtThreshold:SetSize(pnlTabContent:GetWide() * 0.49, pnlTabContent:GetTall() * 0.07)
    txtThreshold:SetPos(0, pnlTabContent:GetTall() * 0.505)
    txtThreshold:SetPlaceholderText(WarningSystem7452em:__("settings_tabs.penalty_points_to_reach"))
    txtThreshold.txt:SetNumeric(true)
    function txtThreshold:OnChange()
        tThreshold.penalty = tonumber(self:GetText())
    end

    local pnlType = vgui.Create("WarningSystem7452em:DComboBox", pnlTabContent)
    pnlType:SetSize(pnlTabContent:GetWide() * 0.49, pnlTabContent:GetTall() * 0.07)
    pnlType:SetPos(pnlTabContent:GetWide() * 0.51, pnlTabContent:GetTall() * 0.505)
    for k, v in pairs(WarningSystem7452em.Thresholds) do
        if( v.Can and not v:Can() ) then continue end
        pnlType:AddChoice(v.Name, k)
    end

    local pnlScrollParams = vgui.Create("WarningSystem7452em:DScrollPanel", pnlTabContent)
    pnlScrollParams:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.3)
    pnlScrollParams:SetPos(0, pnlTabContent:GetTall() * 0.6025)

    function pnlType:OnSelect(iIndex, sValue, xData)
        tThreshold.name = xData
        tThreshold.params = {}

        pnlScrollParams:Clear()

        for k, v in ipairs(WarningSystem7452em.Thresholds[xData].Params) do
            local txtParam = vgui.Create("WarningSystem7452em:DTextEntry", pnlScrollParams)
            txtParam:Dock(TOP)
            txtParam:SetTall(pnlTabContent:GetTall() * 0.07)
            txtParam:DockMargin(0, 0, 0, pnlTabContent:GetTall() * 0.02)
            txtParam:SetPlaceholderText(v.name:gsub("^%l", string.upper))
            function txtParam:OnChange()
                if( v.type == "time" ) then
                    tThreshold.params[k] = WarningSystem7452em:FormatStringToTime(self:GetText())
                else
                    tThreshold.params[k] = self:GetText()
                end
            end
        end
    end

    local btnAdd = vgui.Create("WarningSystem7452em:DButton", pnlTabContent)
    btnAdd:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    btnAdd:SetPos(0, pnlTabContent:GetTall() - btnAdd:GetTall())
    btnAdd:SetText(WarningSystem7452em:__("settings_tabs.add_this_threshold"))
    btnAdd:SetFont("WarningSystem7452em:30M")
    function btnAdd:DoClick()
        if tThreshold.name == "" then return end

        WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
            key = "threshold",
            value = tThreshold
        })

        WarningSystem7452em.Menu:LoadContent("settings", "thresholds")
    end
end

// Permissions
local tPermissions = {
    "add_warn",
    "remove_warn",
    "view_others_warnings",
    "edit_settings",
    "view_note",
    "edit_note"
}

function CATEGORY:ShowPermissions(pnlTabContent)
    local tNewPermissions = table.Copy(WarningSystem7452em.CFG.permissions or {})

    local pnlGroups = vgui.Create("WarningSystem7452em:DComboBox", pnlTabContent)
    pnlGroups:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    for k, v in ipairs(WarningSystem7452em:GetUserGroups()) do
        pnlGroups:AddChoice(v)
    end

    local pnlScroll = vgui.Create("WarningSystem7452em:DScrollPanel", pnlTabContent)
    pnlScroll:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.8)
    pnlScroll:SetPos(0, pnlTabContent:GetTall() * 0.1)
    pnlScroll.Paint = nil

    local pnlList = vgui.Create("DIconLayout", pnlScroll)
    pnlList:SetSize(pnlScroll:GetWide(), pnlScroll:GetTall())
    pnlList:SetSpaceX(pnlList:GetWide() * 0.02)
    pnlList:SetSpaceY(pnlList:GetWide() * 0.02)

    function pnlGroups:OnSelect(iID, sValue, xData)
        pnlList:Clear()

        for k, v in ipairs(tPermissions) do
            local pnlPerm = pnlList:Add("DButton")
            pnlPerm:SetSize(pnlList:GetWide() * 0.49, pnlTabContent:GetTall() * 0.07)
            pnlPerm:SetText("")
            pnlPerm.bEnabled = (tNewPermissions[sValue] or {})[v]
            function pnlPerm:Paint(iW, iH)
                draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
                draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)

                draw.SimpleText(v, "WarningSystem7452em:25M", iW * 0.11, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)

                if self.bEnabled then
                    draw.RoundedBox(8, iH * 0.2, iH * 0.2, iH * 0.6, iH * 0.6, WarningSystem7452em.CFG.theme.Main)
                else
                    draw.RoundedBox(8, iH * 0.2, iH * 0.2, iH * 0.6, iH * 0.6, WarningSystem7452em.CFG.theme.Secondary)
                end
            end
            function pnlPerm:DoClick()
                self.bEnabled = not self.bEnabled

                tNewPermissions[sValue] = tNewPermissions[sValue] or {}
                tNewPermissions[sValue][v] = self.bEnabled
            end
        end
    end

    local btnSave = vgui.Create("WarningSystem7452em:DButton", pnlTabContent)
    btnSave:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    btnSave:SetPos(0, pnlTabContent:GetTall() - btnSave:GetTall())
    btnSave:SetText(WarningSystem7452em:__("settings_tabs.save_those_permissions"))
    btnSave:SetFont("WarningSystem7452em:30M")
    function btnSave:DoClick()
        WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
            key = "permissions",
            value = tNewPermissions
        })

        WarningSystem7452em.Menu:LoadContent("settings", "permissions")
    end
end

// Theme
function CATEGORY:ShowTheme(pnlTabContent)
    local tNewTheme = table.Copy(WarningSystem7452em.CFG.theme)

    local pnlScroll = vgui.Create("WarningSystem7452em:DScrollPanel", pnlTabContent)
    pnlScroll:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.9)
    pnlScroll.Paint = nil

    local iX, iY = 0, 0

    for k, v in pairs(tNewTheme) do
        v = Color(v.r or 255, v.g or 255, v.b or 255, v.a or 255)
        
        local pnlColor = vgui.Create("DPanel", pnlScroll)
        pnlColor:SetSize(pnlScroll:GetWide() * 0.49, pnlTabContent:GetTall() * 0.1)
        pnlColor:SetPos(iX, iY)
        function pnlColor:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)

            draw.SimpleText(k, "WarningSystem7452em:25M", iW * 0.05, iH * 0.5, WarningSystem7452em.CFG.theme.Texts, 0, 1)
        end

        local pnlCube = vgui.Create("DButton", pnlColor)
        pnlCube:SetSize(pnlColor:GetTall() * 0.6, pnlColor:GetTall() * 0.6)
        pnlCube:SetPos(pnlColor:GetWide() - pnlColor:GetTall() * 1, pnlColor:GetTall() * 0.2)
        pnlCube:SetText("")
        pnlCube.cColor = v
        function pnlCube:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Primary)
            draw.RoundedBox(8, 2, 2, iW - 4, iH - 4, self.cColor)
        end
        function pnlCube:DoClick()
            local iX, iY = pnlCube:LocalToScreen(0, self:GetTall() + 5)

            local pnlOver = vgui.Create("EditablePanel")
            pnlOver:SetSize(ScrW(), ScrH())
            pnlOver:MakePopup()
            function pnlOver:OnMousePressed()
                self:Remove()
            end

            local pnlBack = vgui.Create("DPanel", pnlOver)
            pnlBack:SetPos(iX, iY)
            pnlBack:SetSize(ScrH() * 0.3, ScrH() * 0.3)
            function pnlBack:Paint(iW, iH)
            draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
            draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)
            end

            local pnlColorCube = vgui.Create("DColorMixer", pnlBack)
            pnlColorCube:SetSize(pnlBack:GetWide() * 0.9, pnlBack:GetTall() * 0.9)
            pnlColorCube:SetPos(pnlBack:GetWide() * 0.05, pnlBack:GetTall() * 0.05)
            pnlColorCube:SetAlphaBar(true)
            pnlColorCube:SetPalette(true)
            pnlColorCube:SetWangs(true)
            pnlColorCube:SetColor(v)
            function pnlColorCube:ValueChanged(cColor)
                pnlCube.cColor = cColor
                tNewTheme[k] = cColor
            end
        end

        if iX == 0 then
            iX = pnlScroll:GetWide() * 0.51
        else
            iX = 0
            iY = iY + pnlTabContent:GetTall() * 0.13
        end
    end

    local btnSave = vgui.Create("WarningSystem7452em:DButton", pnlTabContent)
    btnSave:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    btnSave:SetPos(0, pnlTabContent:GetTall() - btnSave:GetTall())
    btnSave:SetText(WarningSystem7452em:__("settings_tabs.save_this_theme"))
    btnSave:SetFont("WarningSystem7452em:30M")
    function btnSave:DoClick()
        WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
            key = "theme",
            value = tNewTheme
        })

        WarningSystem7452em.Menu:LoadContent("settings", "theme")
    end
end

function CATEGORY:ShowOther(pnlTabContent)
    local pnlScroll = vgui.Create("DPanel", pnlTabContent)
    pnlScroll:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.9)
    pnlScroll.Paint = nil

    local tKeys = {}

    for k, v in pairs(WarningSystem7452em.CFG) do
        if tOtherBlacklist[k] then
            continue
        end

        tKeys[k] = v

        local lblCfg = Label(k, pnlScroll)
        lblCfg:Dock(TOP)
        lblCfg:SetFont("WarningSystem7452em:25M")
        lblCfg:SetTextColor(WarningSystem7452em.CFG.theme.Texts)
    
        local txtCfg = vgui.Create("WarningSystem7452em:DTextEntry", pnlScroll)
        txtCfg:Dock(TOP)
        txtCfg:SetTall(pnlTabContent:GetTall() * 0.08)
        txtCfg:SetText(v)
        txtCfg:DockMargin(0, txtCfg:GetTall() * 0.1, 0, txtCfg:GetTall() * 0.3)
        function txtCfg:OnChange()
            tKeys[k] = self:GetText()
        end
    end

    local btnSave = vgui.Create("WarningSystem7452em:DButton", pnlTabContent)
    btnSave:SetSize(pnlTabContent:GetWide(), pnlTabContent:GetTall() * 0.07)
    btnSave:SetPos(0, pnlTabContent:GetTall() - btnSave:GetTall())
    btnSave:SetText(WarningSystem7452em:__("settings_tabs.save_this_config"))
    btnSave:SetFont("WarningSystem7452em:30M")
    function btnSave:DoClick()
        WarningSystem7452em:NetStart("WarningSystem7452em:Player:UpdateSettings", {
            keys = tKeys,
        })

        WarningSystem7452em.Menu:LoadContent("settings", "other")
    end
end

function CATEGORY:onOpen(pnlContent, ...)
    local pnlTabContent

    local tTabs = {
        ["preset_reasons"] = {
            title = WarningSystem7452em:__("settings_tabs.preset_reasons"),
            callback = function(pnlTabContent)
                CATEGORY:ShowPresetReasons(pnlTabContent)
            end,
            order = 1
        },
        ["thresholds"] = {
            title = WarningSystem7452em:__("settings_tabs.thresholds"),
            callback = function(pnlTabContent)
                CATEGORY:ShowThresholds(pnlTabContent)
            end,
            order = 2
        },
        ["permissions"] = {
            title = WarningSystem7452em:__("settings_tabs.permissions"),
            callback = function(pnlTabContent)
                CATEGORY:ShowPermissions(pnlTabContent)
            end,
            order = 3
        },
        ["theme"] = {
            title = WarningSystem7452em:__("settings_tabs.theme"),
            callback = function(pnlTabContent)
                CATEGORY:ShowTheme(pnlTabContent)
            end,
            order = 4
        },
        ["other"] = {
            title = WarningSystem7452em:__("settings_tabs.other"),
            callback = function(pnlTabContent)
                CATEGORY:ShowOther(pnlTabContent)
            end,
            order = 5
        },
    }

    local xArgs = {...}

    function pnlContent:Paint(iW, iH)
    end

    local pnlTabs = vgui.Create("DPanel", pnlContent)
    pnlTabs:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.08)
    pnlTabs.Paint = nil

    local function updateButtons(pnl)
        for k, v in ipairs(pnlTabs:GetChildren()) do
            v:SetBackgroundColor(v == pnl and WarningSystem7452em.CFG.theme.Main or WarningSystem7452em.CFG.theme.Tertiary)
            v:SetBorder(WarningSystem7452em.CFG.theme.Secondary, v == pnl and 0 or 1)
        end
    end

    pnlTabContent = vgui.Create("DPanel", pnlContent)
    pnlTabContent:SetPos(0, pnlContent:GetTall() * 0.1)
    pnlTabContent:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.9)
    pnlTabContent.Paint = nil

    local iOffsetX = 0
    for k, v in SortedPairsByMemberValue(tTabs, "order") do   
        surface.SetFont("WarningSystem7452em:30M")
        local iWide = surface.GetTextSize(v.title)

        local btnTab = vgui.Create("WarningSystem7452em:DButton", pnlTabs)
        btnTab:SetSize(iWide + pnlTabs:GetTall() * 0.5, pnlTabs:GetTall())
        btnTab:SetBackgroundColor(WarningSystem7452em.CFG.theme.Tertiary)
        btnTab:SetPos(iOffsetX, 0)
        btnTab:SetText(v.title)
        btnTab:SetFont("WarningSystem7452em:30M")
        btnTab:SetBorder(WarningSystem7452em.CFG.theme.Secondary, 1)
        function btnTab:DoClick()
            pnlTabContent:Clear()
            pnlTabContent.Paint = nil
            updateButtons(self)
            v.callback(pnlTabContent)
        
            WarningSystem7452em.tLastLoaded[2] = k
        end

        if xArgs[1] ~= nil and xArgs[1] == k then
            btnTab:DoClick()
        end

        iOffsetX = iOffsetX + btnTab:GetWide() + pnlTabs:GetTall() * 0.2
    end

    if not xArgs[1] then
        pnlTabs:GetChild(0):DoClick()
    end
end

WarningSystem7452em:AddCategory("settings", CATEGORY)
