local xTotal = Material("materials/warning_system/warning.png", "noclamp smooth")
local xPenalty = Material("materials/warning_system/error.png", "noclamp smooth")
local xMonthly = Material("materials/warning_system/calendar.png", "noclamp smooth")

local CATEGORY = {}

CATEGORY.Order = 5
CATEGORY.title = WarningSystem7452em:__("tabs.statistics")
CATEGORY.icon = Material("materials/warning_system/chart.png", "noclamp smooth")

function CATEGORY:isAllowed(pPlayer)
    self.title = WarningSystem7452em:__("tabs.statistics")

    return WarningSystem7452em:Can(pPlayer, "view_stats")
end

function CATEGORY:onLoad()
    WarningSystem7452em:NetStart("WarningSystem7452em:Player:GetInfo", {
        type = "stats",
        target = "null"
    })
end

function CATEGORY:onOpen(pnlContent, ...)
    local tShowLeaderboards = WarningSystem7452em.Stats and WarningSystem7452em.Stats.apiKey or false

    function pnlContent:Paint(iW, iH)
        WarningSystem7452em:DrawCard(WarningSystem7452em:__("total_warnings"), WarningSystem7452em.Stats.total_warnings, xTotal, 0, 0, iW * 0.32, iH * 0.15)
        WarningSystem7452em:DrawCard(WarningSystem7452em:__("total_penalty_points"), WarningSystem7452em.Stats.total_penalty_points, xPenalty, iW * 0.34, 0, iW * 0.32, iH * 0.15)
        WarningSystem7452em:DrawCard(WarningSystem7452em:__("monthly_warnings"), WarningSystem7452em.Stats.monthly_warnings, xMonthly, iW * 0.68, 0, iW * 0.32, iH * 0.15)

        if not tShowLeaderboards then
            draw.SimpleText(WarningSystem7452em:__("set_api_key"), "WarningSystem7452em:30M", iW * 0.5, iH * 0.8, WarningSystem7452em.CFG.theme.Texts, 1, 1)
        end
    end

    local iValues = WarningSystem7452em.Stats and WarningSystem7452em.Stats.graph or {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

    local iMax = math.max(unpack(iValues))
    local iMaxValue = math.ceil(iMax / 10) * 10
    
    local iMonths = WarningSystem7452em:__("months")

    local iSize = pnlContent:GetWide() * 0.85 / 12

    local pnlChart = vgui.Create("DPanel", pnlContent)
    pnlChart:SetSize(pnlContent:GetWide(), pnlContent:GetTall() * 0.4)    
    pnlChart:SetPos(0, pnlContent:GetTall() * 0.17)
    function pnlChart:Paint(iW, iH)
        draw.RoundedBox(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Secondary)
        draw.RoundedBox(8, 1, 1, iW - 2, iH - 2, WarningSystem7452em.CFG.theme.Tertiary)

        draw.SimpleText(WarningSystem7452em:__("monthly_warnings"), "WarningSystem7452em:25M", iW * 0.02, iH * 0.03, WarningSystem7452em.CFG.theme.Texts2)
    
        draw.SimpleText(iMaxValue, "WarningSystem7452em:25M", iW * 0.05, iH * 0.225, WarningSystem7452em.CFG.theme.Texts, 1, 1)
        draw.SimpleText(0, "WarningSystem7452em:25M", iW * 0.05, iH * 0.85, WarningSystem7452em.CFG.theme.Texts, 1, 1)

        for i = 1, 12 do
            draw.SimpleText(iMonths[i], "WarningSystem7452em:25M", iW * 0.1 + iSize * (i - 1) + iSize * 0.5, iH * 0.875, WarningSystem7452em.CFG.theme.Texts, 1)
        end

        surface.SetDrawColor(WarningSystem7452em.CFG.theme.Texts)
        surface.DrawLine(iW * 0.1, iH * 0.225, iW * 0.1, iH * 0.85)
        surface.DrawLine(iW * 0.1, iH * 0.85, iW * 0.95, iH * 0.85)
    end

    local iW, iH = pnlChart:GetSize()

    for i = 1, 12 do
        local iBarH = (iValues[i] * iH * 0.625) / iMaxValue

        local pnlMonth = vgui.Create("DPanel", pnlChart)
        pnlMonth:SetPos(iW * 0.1 + iSize * (i - 1) + iSize * 0.25, iH * 0.85 - iBarH)
        pnlMonth:SetSize(iSize * 0.5, iBarH)
        pnlMonth.sText = iValues[i]
        surface.SetFont("WarningSystem7452em:25M")
        pnlMonth.iTextW = surface.GetTextSize(pnlMonth.sText)
        function pnlMonth:Paint(iW, iH)
            draw.RoundedBoxEx(8, 0, 0, iW, iH, WarningSystem7452em.CFG.theme.Main, true, true)

            if self:IsHovered() then
                DisableClipping(true)
                    draw.RoundedBox(8, -self.iTextW * 0.5, -iW * 1.5, iW + self.iTextW, iW * 1.3, WarningSystem7452em.CFG.theme.Primary)

                    draw.SimpleText(self.sText, "WarningSystem7452em:25M", iW * 0.5, -iW * 0.75, WarningSystem7452em.CFG.theme.Texts, 1, 1)
                DisableClipping(false)
            end
        end
        function pnlMonth:OnCursorEntered()
            self:MoveToFront()
        end         
    end

    if not tShowLeaderboards then return end

    local pnlLastWarnings = vgui.Create("WarningSystem7452em:Leaderboard", pnlContent)
    pnlLastWarnings:SetSize(pnlContent:GetWide() * 0.32, pnlContent:GetTall() * 0.41)
    pnlLastWarnings:SetPos(0, pnlContent:GetTall() * 0.59)
    pnlLastWarnings:Setup(WarningSystem7452em:__("last_warnings"), WarningSystem7452em.CFG.theme.Red)
    for k,v in pairs(WarningSystem7452em.Stats.last_warnings or {}) do
        local sAvatar = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].avatar or ""
        local sName = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].name or v.steamid

        pnlLastWarnings:AddRow(
            sAvatar,
            sName,
            v.penalty
        )
    end
    
    local pnlMostWarned = vgui.Create("WarningSystem7452em:Leaderboard", pnlContent)
    pnlMostWarned:SetSize(pnlContent:GetWide() * 0.32, pnlContent:GetTall() * 0.41)
    pnlMostWarned:SetPos(pnlContent:GetWide() * 0.34, pnlContent:GetTall() * 0.59)
    pnlMostWarned:Setup(WarningSystem7452em:__("most_warned"), WarningSystem7452em.CFG.theme.Orange)
    for k,v in pairs(WarningSystem7452em.Stats.most_warned or {}) do
        local sAvatar = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].avatar or ""
        local sName = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].name or v.steamid

        pnlMostWarned:AddRow(
            sAvatar,
            sName,
            v.amount
        )
    end
    
    local pnlStaffLeaderboard = vgui.Create("WarningSystem7452em:Leaderboard", pnlContent)
    pnlStaffLeaderboard:SetSize(pnlContent:GetWide() * 0.32, pnlContent:GetTall() * 0.41)
    pnlStaffLeaderboard:SetPos(pnlContent:GetWide() * 0.68, pnlContent:GetTall() * 0.59)
    pnlStaffLeaderboard:Setup(WarningSystem7452em:__("staff_leaderboard"), WarningSystem7452em.CFG.theme.Green)
    for k,v in pairs(WarningSystem7452em.Stats.staff_leaderboards or {}) do
        local sAvatar = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].avatar or ""
        local sName = WarningSystem7452em.Stats.users and WarningSystem7452em.Stats.users[v.steamid .. "_"] and WarningSystem7452em.Stats.users[v.steamid .. "_"].name or v.steamid

        pnlStaffLeaderboard:AddRow(
            sAvatar,
            sName,
            v.amount
        )
    end
end

WarningSystem7452em:AddCategory("statistics", CATEGORY)
