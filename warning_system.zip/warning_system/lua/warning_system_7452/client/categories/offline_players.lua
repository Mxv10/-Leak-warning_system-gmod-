local CATEGORY = {}

CATEGORY.Order = 3
CATEGORY.title = WarningSystem7452em:__("tabs.offline_players")
CATEGORY.icon = Material("materials/warning_system/search.png", "noclamp smooth")

function CATEGORY:isAllowed(pPlayer)
    self.title = WarningSystem7452em:__("tabs.offline_players")

    return WarningSystem7452em:Can(pPlayer, "view_others_warnings")
end

function CATEGORY:onOpen(pnlContent, ...)
    function pnlContent:Paint(iW, iH)
        draw.SimpleText(WarningSystem7452em:__("search_player_sid64"), "WarningSystem7452em:30M", iW * 0.5, iH * 0.47, WarningSystem7452em.CFG.theme.Texts2, 1, 1)
    end

    local txtSearch = vgui.Create("WarningSystem7452em:DTextEntry", pnlContent)
    txtSearch:SetSize(pnlContent:GetWide() * 0.64, pnlContent:GetTall() * 0.07)
    txtSearch:SetPos(pnlContent:GetWide() * 0.15, pnlContent:GetTall() * 0.51)
    txtSearch.txt:SetPlaceholderText("7656...")
    txtSearch.txt:SetNumeric(true)

    local btnSearch = vgui.Create("WarningSystem7452em:DImageButton", pnlContent)
    btnSearch:SetImage("materials/warning_system/arrow_forward.png")
    btnSearch:SetSize(pnlContent:GetTall() * 0.07, pnlContent:GetTall() * 0.07)
    btnSearch:SetPos(pnlContent:GetWide() * 0.8, pnlContent:GetTall() * 0.51)

    local function search()
        if IsValid(WarningSystem7452em.Menu) then
            WarningSystem7452em.Menu:LoadContent("my_warnings", txtSearch:GetText())
        end
    end

    function btnSearch:DoClick()
        search()
    end
    function txtSearch:OnEnter()
        search()
    end
end

WarningSystem7452em:AddCategory("offline_players", CATEGORY)