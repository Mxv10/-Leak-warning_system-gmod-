WarningSystem7452em.Lang["en"] = {
    tabs = {
        my_warnings = "My Warnings",
        offline_players = "Offline Players",
        online_players = "Online Players",
        settings = "Settings",
        statistics = "Statistics",
    },

    settings_tabs = {
        preset_reasons = "Preset Reasons",
        thresholds = "Thresholds",
        permissions = "Permissions",
        theme = "Theme",
        other = "Other",

        add_this_reason = "Add this reason",
        penalty_points_to_reach = "Penalty points to reach",
        add_this_threshold = "Add this threshold",
        save_those_permissions = "Save those permissions",
        save_this_theme = "Save this theme for everyone",
        save_this_config = "Save this configuration",
    },

    webhooks = {
        new_warning = "New Warning",
        warning_removed = "Warning Removed",

        user = "User",
        admin = "Administrator",
        more_info = "More Information",
    },

    errors = {
        no_access = "You do not have access to this",
        reason_too_short = "Reason too short",
        reason_too_long = "Reason too long",
        invalid_key = "Invalid key",
    },

    notifs = {
        success = "Success",
        error = "Error",
        warning = "Warning",
    },

    youve_been_warned = "You have been warned",
    player_been_warned = "The player has been warned successfully",
    player_been_unwarned = "The player has been unwarned successfully",

    settings_updated = "Settings updated",

    awarn_imported = "Warnings from AWarn3 imported!",

    by = "By",
    reason = "Reason",
    penalty = "Penalty",
    date = "Date",
    expiration = "Expiration",
    duration = "Duration",
    preset = "Preset",

    none = "None",

    warn = "Warn",

    custom_warning = "Custom Warning",

    penalty_points = "Penalty Points",

    warn_this_player = "Warn this player",

    search_player_sid64 = "Search for a player by its SteamID x64 (7656...)",
    search_player = "Search for a player...",

    x_displayed = "%i displayed",
    x_online_players = "%i Online Players",

    total_warnings = "Total Warnings",
    total_penalty_points = "Total Penalty Points",
    monthly_warnings = "Monthly Warnings",
    last_warnings = "Last Warnings",
    most_warned = "Most Warned",
    staff_leaderboard = "Staff Leaderboard",
    active_warnings = "Active Warnings",

    view_more = "View More",

    joins_with_x = "%s joins the server with %s warnings",

    set_api_key = "You must set a Steam API key",

    months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"}
}