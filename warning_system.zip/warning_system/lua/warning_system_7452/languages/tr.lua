WarningSystem7452em.Lang["tr"] = {
	tabs = {
		my_warnings = "Uyarılarım",
		offline_players = "Çevrimdışı Oyuncular",
		online_players = "Çevrimiçi Oyuncular",
		settings = "Ayarlar",
		statistics = "İstatistik",
	},

	settings_tabs = {
		preset_reasons = "Önceden Ayarlanmış Nedenler",
		thresholds = "Eşikler",
		permissions = "İzinler",
		theme = "Tema",
		other = "Diğer",

		add_this_reason = "Bu nedeni ekleyin",
		penalty_points_to_reach = "Ulaşılacak ceza puanları",
		add_this_threshold = "Bu eşiği ekleyin",
		save_those_permissions = "Bu izinleri kaydedin",
		save_this_theme = "Bu temayı herkes için kaydedin",
		save_this_config = "Bu ayarları kaydedin",
	},

	webhooks = {
		new_warning = "Yeni Uyarı",
		warning_removed = "Uyarı Kaldırıldı",

		user = "Kullanıcı",
		admin = "Yetkili",
		more_info = "Daha fazla bilgi",
	},

	errors = {
		no_access = "Buna erişiminiz yok",
		reason_too_short = "Nedeni çok kısa",
		reason_too_long = "Reason too long",
		invalid_key = "Nedeni çok uzun",
	},

	notifs = {
		success = "Başarıyla",
		error = "Hata",
		warning = "Uyarı",
	},

	youve_been_warned = "Uyarıldın",
	player_been_warned = "Oyuncu başarıyla uyarıldı",
	player_been_unwarned = "Oyuncu başarıyla uyarılmadı",

	settings_updated = "Ayarlar güncellendi",

	awarn_imported = "AWarn3'ten gelen uyarılar içe aktarıldı!",

	by = "Tarafından",
	reason = "Nedeni",
	penalty = "Ceza",
	date = "Tarih",
	expiration = "Son",
	duration = "Süresi",
	preset = "Ön ayar",

	none = "Yok",

	warn = "Uyar",

	custom_warning = "Özel Uyarı",

	penalty_points = "Ceza puanları",

	warn_this_player = "Bu oyuncuyu uyar",

	search_player_sid64 = "SteamID x64 (7656 ...) ile bir oyuncu arayın",
	search_player = "Oyuncu ara ...",

	x_displayed = "%i görüntülendi",
	x_online_players = "%i Çevrimiçi Oyuncular",

	total_warnings = "Toplam Uyarılar",
	total_penalty_points = "Toplam Ceza Puanı",
	monthly_warnings = "Aylık Uyarılar",
	last_warnings = "Son Uyarılar",
	most_warned = "En Çok Uyarılan",
	staff_leaderboard = "Yetkili Lider Tablosu",
	active_warnings = "Aktif Uyarılar",

	view_more = "Daha fazla göster",

	joins_with_x = "%s , sunucuya %s uyarısyla katılıyor",

	set_api_key = "Bir Steam API anahtarı koymalısınız",

	months = {"Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara"}
}
