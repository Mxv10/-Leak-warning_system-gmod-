WarningSystem7452em.Lang["de"] = {
    tabs = {
        my_warnings = "Meine Verwarnungen",
        offline_players = "Offline-Spieler",
        online_players = "Online-Spieler",
        settings = "Einstellungen",
        statistics = "Statistiken",
    },
 
    settings_tabs = {
        preset_reasons = "Voreingestellte Gründe",
        thresholds = "Schwellenwerte",
        permissions = "Berechtigungen",
        theme = "Theme",
        other = "Anderes",
 
        add_this_reason = "Füge diesen Grund hinzu",
        penalty_points_to_reach = "Strafpunkte zu erreichen",
        add_this_threshold = "Diesen Schwellenwert hinzufügen",
        save_those_permissions = "Diese Berechtigungen speichern",
        save_this_theme = "Dieses Theme für alle Spieler speichern",
        save_this_config = "Konfiguration speichern",
    },
 
    webhooks = {
        new_warning = "Neue Verwarnung",
        warning_removed = "Verwarnung entfernt",
 
        user = "Spieler",
        admin = "Administrator",
        more_info = "Weitere Informationen",
    },
 
    errors = {
        no_access = "Du hast darauf keinen Zugriff!",
        reason_too_short = "Grund zu kurz",
        reason_too_long = "Grund zu lang",
        invalid_key = "Ungültiger Schlüssel",
    },
 
    notifs = {
        success = "Erfolg",
        error = "Error",
        warning = "Warnung",
    },
 
    youve_been_warned = "Du wurdest verwarnt",
    player_been_warned = "Der Spieler wurde erfolgreich verwarnt",
    player_been_unwarned = "Der Spieler wurde erfolgreich entwarnt.",
 
    settings_updated = "Einstellungen aktualisiert",
 
    awarn_imported = "Verwarnungen von AWarn3 importiert!",
 
    by = "Von",
    reason = "Grund",
    penalty = "Strafe",
    date = "Datum",
    expiration = "Ablauf",
    duration = "Dauer",
    preset = "Voreinstellung",
 
    none = "Keiner",
 
    warn = "Verwarnen",
 
    custom_warning = "Selbstdefinierte Verwarnung",
 
    penalty_points = "Strafpunkte",
 
    warn_this_player = "Verwarne diesen Spieler",
 
    search_player_sid64 = "Suche nach einem Spieler anhand seiner SteamID x64 (7656 ...)",
    search_player = "Suche nach einem Spieler...",
 
    x_displayed = "%i angezeigt",
    x_online_players = "%i Spieler online",
 
    total_warnings = "Gesamte Verwarnungen",
    total_penalty_points = "Gesamte Strafpunkte",
    monthly_warnings = "Monatliche Verwarnungen",
    last_warnings = "Letzte Verwarnungen",
    most_warned = "Am meisten verwarnt",
    staff_leaderboard = "Team-Rangliste",
    active_warnings = "Aktive Verwarnungen",
 
    view_more = "Mehr ansehen",
 
    joins_with_x = "%s tritt dem Server mit %s Verwarnungen bei",
 
    set_api_key = "Du musst einen Steam-API-Schlüssel festlegen",
 
    months = {"Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"}
}
