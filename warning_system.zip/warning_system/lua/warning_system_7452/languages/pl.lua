WarningSystem7452em.Lang["pl"] = {
	tabs = {
		my_warnings = "Moje ostrzeżenia",
		offline_players = "Wylogowani gracze",
		online_players = "Zalogowani gracze",
		settings = "Opcje",
		statistics = "Statystyki",
	},

	settings_tabs = {
		preset_reasons = "Powów nadania",
		thresholds = "Próg punktowy",
		permissions = "Permisje",
		theme = "Motyw",
		other = "Inne",

		add_this_reason = "Dodaj powód",
		penalty_points_to_reach = "Punkty kary do osiągnięcia",
		add_this_threshold = "Dodaj wagę (próg)",
		save_those_permissions = "Zapisz permisje",
		save_this_theme = "Zapisz motyw dla każdego",
		save_this_config = "Zapisz konfigurację",
	},

	webhooks = {
		new_warning = "Nowe ostrzeżenie",
		warning_removed = "Rozszerzenie usunięte",

		user = "Gracz",
		admin = "Administrator",
		more_info = "Więcej informacji",
	},

	errors = {
		no_access = "Nie masz do tego dostępu",
		reason_too_short = "Zbyt krótki powód",
		reason_too_long = "Zbyt długi powód",
		invalid_key = "Niepoprawny klucz",
	},

	notifs = {
		success = "Sukces",
		error = "Błąd",
		warning = "Ostrzeżenie",
	},

	youve_been_warned = "Dostałeś ostrzeżenie",
	player_been_warned = "Gracz dostał ostrzeżenie",
	player_been_unwarned = "Usunąłeś ostrzeżenie",

	settings_updated = "Zmieniłeś ustawienia",

	awarn_imported = "Ostrzeżenia z AWarn3 załadowane",

	by = "Od",
	reason = "Powód",
	penalty = "Kara",
	date = "Data",
	expiration = "Wygasa",
	duration = "Trwanie",
	preset = "Ustawienie",

	none = "Bral",

	warn = "Ostrzeżenie",

	custom_warning = "Własne ostrzeżenie",

	penalty_points = "Punkty karne",

	warn_this_player = "Nadaj ostrzeżenie",

	search_player_sid64 = "Wyszukaj gracza przez SteamID x64 (7656...)",
	search_player = "Znajdź gracza...",

	x_displayed = "%i pokazani",
	x_online_players = "%i Aktywni gracze",

	total_warnings = "Wszystkie ostrzeżenia",
	total_penalty_points = "Wszystkie punkty karne",
	monthly_warnings = "Miesięczne ostrzeżenie",
	last_warnings = "Ostatnie ostrzeżenie",
	most_warned = "Najczęściej karany",
	staff_leaderboard = "Tabela administracji",
	active_warnings = "Aktywne ostrzeżenia",

	view_more = "Pokaż więcej",

	joins_with_x = "%s dołącza na serwer z %s ostrzeżeniami",

	set_api_key = "Musisz ustawić Steam API key",

	months = {"Sty", "Lut", "Mar", "Kwi", "Maj", "Cze", "Lip", "Sie", "Wrz", "Paź", "Lis", "Gru"}
}
