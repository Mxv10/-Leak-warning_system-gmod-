WarningSystem7452em.Lang["ru"] = {
	tabs = {
		my_warnings = "Ваши Варны",
		offline_players = "Игроки Оффлайн",
		online_players = "Игроки Онлайн",
		settings = "Настройки",
		statistics = "Статистика",
	},

	settings_tabs = {
		preset_reasons = "Шаблоны причин",
		thresholds = "Наказания",
		permissions = "Разрешения",
		theme = "Тема",
		other = "Другое",

		add_this_reason = "Добавить причину",
		penalty_points_to_reach = "Количество очков для наказания",
		add_this_threshold = "Добавить наказание",
		save_those_permissions = "Сохранить",
		save_this_theme = "Сохранить",
		save_this_config = "Сохранить",
	},

	webhooks = {
		new_warning = "Новый Варн",
		warning_removed = "Варн снят",

		user = "Игрок",
		admin = "Администратор",
		more_info = "Подробнее",
	},

	errors = {
		no_access = "У вас нет доступа к этому",
		reason_too_short = "Причина слишком короткая",
		reason_too_long = "Причина слишком длинная",
		invalid_key = "Невалидный ключ",
	},

	notifs = {
		success = "Удачно",
		error = "Ошибка",
		warning = "Предупреждение",
	},

	youve_been_warned = "Вы получили варн",
	player_been_warned = "Игрок успешно получил варн",
	player_been_unwarned = "Варн был успешно снят",

	settings_updated = "Настройки обновлены!",

	awarn_imported = "Варны из AWarn3 импортированы!",

	by = "Кем",
	reason = "Причина",
	penalty = "Очков",
	date = "Дата",
	expiration = "Истекает",
	duration = "Срок",
	preset = "Шаблон",

	none = "Нет",

	warn = "Варн",

	custom_warning = "Выдать варн",

	penalty_points = "Очков наказания",

	warn_this_player = "Выдать варн",

	search_player_sid64 = "Поиск игрока по SteamID x64 (7656...)",
	search_player = "Поиск игрока...",

	x_displayed = "%i отображён",
	x_online_players = "%i Игроков онлайн",

	total_warnings = "Всего варнов",
	total_penalty_points = "Всего очков наказания",
	monthly_warnings = "Варнов в месяц",
	last_warnings = "Последний Варн",
	most_warned = "Больше всего",
	staff_leaderboard = "Лидер наказаний",
	active_warnings = "Активный Варн",

	view_more = "Посмотреть больше",

	joins_with_x = "%s зашёл на сервер с %s варнами",

	set_api_key = "Вы должны установить ключ Steam API",

	months = {"Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"}
}
