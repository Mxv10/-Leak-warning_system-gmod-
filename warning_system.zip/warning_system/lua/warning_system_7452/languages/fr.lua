WarningSystem7452em.Lang["fr"] = {
    tabs = {
        my_warnings = "Mes Avertissements",
        offline_players = "Joueurs Hors-Ligne",
        online_players = "Joueurs En-Ligne",
        settings = "Paramètres",
        statistics = "Statistiques",
    },

    settings_tabs = {
        preset_reasons = "Raisons Prédéfinies",
        thresholds = "Seuils",
        permissions = "Permissions",
        theme = "Thème",
        other = "Autre",

        add_this_reason = "Ajouter cette raison",
        penalty_points_to_reach = "Points de pénalité à atteindre",
        add_this_threshold = "Ajouter ce seuil",
        save_those_permissions = "Enregistrer ces permissions",
        save_this_theme = "Enregistrer ce thème pour tout le monde",
        save_this_config = "Enregistrer cette configuration",
    },

    webhooks = {
        new_warning = "Nouvel Avertissement",
        warning_removed = "Avertissement Retiré",

        user = "Utilisateur",
        admin = "Administrateur",
        more_info = "Plus d'Informations",
    },

    errors = {
        no_access = "Vous n'avez pas accès à cela",
        reason_too_short = "Raison trop courte",
        reason_too_long = "Raison trop longue",
        invalid_key = "Clé invalide",
    },

    notifs = {
        success = "Succès",
        error = "Erreur",
        warning = "Attention",
    },

    youve_been_warned = "Vous avez été averti",
    player_been_warned = "Ce joueur a été averti avec succès",
    player_been_unwarned = "Ce joueur a été désaverti avec succès",

    settings_updated = "Paramètres mis à jour",

    awarn_imported = "Les avertissements d'AWarn3 ont été importés !",

    by = "Par",
    reason = "Raison",
    penalty = "Pénalité",
    date = "Date",
    expiration = "Expiration",
    duration = "Durée",
    preset = "Préréglage",

    none = "Aucun",

    warn = "Avertir",

    custom_warning = "Avertissement personnalisé",

    penalty_points = "Points de Pénalité",

    warn_this_player = "Avertir ce joueur",

    search_player_sid64 = "Rechercher un joueur par son SteamID x64 (7656...)",
    search_player = "Rechercher un joueur...",

    x_displayed = "%i affichés",
    x_online_players = "%i Joueurs en Ligne",

    total_warnings = "Avertissements Totaux",
    total_penalty_points = "Points de Pénalité Totaux",
    monthly_warnings = "Avertissements Mensuels",
    last_warnings = "Derniers avertissements",
    most_warned = "Les Plus Avertis",
    staff_leaderboard = "Administrateurs Efficaces",
    active_warnings = "Avertissements Actifs",

    view_more = "Voir Plus",

    joins_with_x = "%s rejoint le serveur avec %s avertissements",

    set_api_key = "Vous devez définir une clé d'API Steam",

    months = {"Jan", "Fev", "Mar", "Avr", "Mai", "Juin", "Juil", "Aoû", "Sep", "Oct", "Nov", "Déc"}
}
