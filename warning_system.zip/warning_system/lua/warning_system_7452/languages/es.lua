WarningSystem7452em.Lang["es"] = {
	tabs = {
		my_warnings = "Mis Advertencias",
		offline_players = "Jugadores Desconectados",
		online_players = "Jugadores En Línea",
		settings = "Ajustes",
		statistics = "Estadísticas",
	},
 
	settings_tabs = {
		preset_reasons = "Razones predefinidas",
		thresholds = "Límites",
		permissions = "Permisos",
		theme = "Tema",
		other = "Otro",
 
		add_this_reason = "Agregar esta razón",
		penalty_points_to_reach = "Puntos de penalización para alcanzar",
		add_this_threshold = "Agregar este límite",
		save_those_permissions = "Guardar esos permisos",
		save_this_theme = "Guardar este tema para todos",
		save_this_config = "Guardar esta configuración",
	},
 
	webhooks = {
		new_warning = "Nueva Advertencia",
		warning_removed = "Advertencia Removida",
 
		user = "Usuario",
		admin = "Administrador",
		more_info = "Más Información",
	},
 
	errors = {
		no_access = "No tienes acceso a esto",
		reason_too_short = "La razón es demasiado corta",
		reason_too_long = "La razón es demasiado larga",
		invalid_key = "Tecla inválida",
	},
 
	notifs = {
		success = "Éxito",
		error = "Error",
		warning = "Advertencia",
	},
 
	youve_been_warned = "Se te ha agregado una advertencia",
	player_been_warned = "El jugador fue advertido satisfactoriamente",
	player_been_unwarned = "Se removió la advertencia satisfactoriamente",
 
	settings_updated = "Ajustes actualizados",
 
	awarn_imported = "¡Advertencias de AWarn3 importadas!",
 
	by = "Por",
	reason = "Razón",
	penalty = "Penalización",
	date = "Fecha",
	expiration = "Expiración",
	duration = "Duración",
	preset = "Predeterminado",
 
	none = "Nada",
 
	warn = "Advertencia",
 
	custom_warning = "Advertencia personalizada",
 
	penalty_points = "Puntos de penalización",
 
	warn_this_player = "Advertir a este jugador",
 
	search_player_sid64 = "Buscar a un jugador por su SteamID x64 (7656...)",
	search_player = "Buscar jugador...",
 
	x_displayed = "%i mostrados",
	x_online_players = "%i Jugadores en línea",
 
	total_warnings = "Advertencias totales",
	total_penalty_points = "Puntos de penalización totales",
	monthly_warnings = "Advertencias mensuales",
	last_warnings = "Últimas advertencias",
	most_warned = "Los más advertidos",
	staff_leaderboard = "Clasificación del staff",
	active_warnings = "Advertencias activas",
 
	view_more = "Ver más",
 
	joins_with_x = "%s ingresó al servidor con %s advertencias",
 
	set_api_key = "Debes establecer una Steam API key",
 
	months = {"Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"}
}
