WarningSystem7452em = WarningSystem7452em or {}
WarningSystem7452em.CFG = WarningSystem7452em.CFG or {}
WarningSystem7452em.Lang = WarningSystem7452em.Lang or {}

local sMainDir = "warning_system_7452/"

local function loadDirectory(sDir, sFileType)
    local tblFiles, tDirs = file.Find(sMainDir .. sDir .. "*", "LUA")

    for k, v in pairs(tblFiles) do
        if sFileType == "server" then
            if SERVER then include(sMainDir .. sDir .. v) end
        elseif sFileType == "client" then
            if SERVER then
                AddCSLuaFile(sMainDir .. sDir .. v)
            else
                include(sMainDir .. sDir .. v)
            end
        elseif sFileType == "shared" then
            if SERVER then AddCSLuaFile(sMainDir .. sDir .. v) end
            include(sMainDir .. sDir .. v)
        end
    end

    for k, v in pairs(tDirs) do
        loadDirectory(sDir .. v .. "/", sFileType)
    end
end

function WarningSystem7452em:__(strTag)
    local tParts = string.Explode(".", strTag)

    local tLang = WarningSystem7452em.Lang[WarningSystem7452em.CFG.Language or "en"]

    for k, v in ipairs(tParts) do
        tLang = tLang[v] or tLang
    end

    return tLang or strTag
end

loadDirectory("languages/", "shared")
loadDirectory("shared/", "shared")
loadDirectory("client/", "client")
loadDirectory("server/", "server")
