local MODULE = GAS.Logging:MODULE()
MODULE.Category = "Warning System"

MODULE.Name = "Warnings Added"
MODULE.Colour = Color(255,0,0)

MODULE:Setup(function()
	MODULE:Hook("WarningSystem7452em:Player:Warn", "blogs", function(pPlayer, tInfo)
		MODULE:Log("{1} has warned " .. tInfo.victim .. " : " .. tInfo.reason, GAS.Logging:FormatPlayer(pPlayer))
	end)
end)

GAS.Logging:AddModule(MODULE)

local MODULE = GAS.Logging:MODULE()
MODULE.Category = "Warning System"

MODULE.Name = "Warnings Removed"
MODULE.Colour = Color(255,0,0)

MODULE:Setup(function()
	MODULE:Hook("WarningSystem7452em:Player:UnWarn", "blogs", function(pPlayer, tInfo)
		MODULE:Log("{1} has removed the warning of " .. tInfo.victim, GAS.Logging:FormatPlayer(pPlayer))
	end)
end)

GAS.Logging:AddModule(MODULE)